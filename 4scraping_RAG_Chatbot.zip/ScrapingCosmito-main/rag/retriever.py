import os
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings
import logging

import sys 
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DocumentRetriever:
    def __init__(self, persist_directory: str = "storage/chroma_db"):
        """
        Système de récupération RAG Multi-Collection (Produits & Ingrédients)
        """
        self.persist_directory = persist_directory
        self.client = None
        
        # Références vers les collections
        self.product_collection = None
        self.ingredient_collection = None
        
        # Noms des collections (configurables)
        self.PRODUCT_COLLECTION_NAME = "cosmetovigilance_docs"
        self.INGREDIENT_COLLECTION_NAME = "cosmetovigilance_ingredients"  # Nouveau !

        self._initialize_client()
        self._load_collections()

    def _initialize_client(self):
        """Initialise le client ChromaDB"""
        try:
            self.client = chromadb.PersistentClient(
                path=self.persist_directory,
                settings=Settings(anonymized_telemetry=False)
            )
            logger.info("✅ Client ChromaDB initialisé")
        except Exception as e:
            logger.error(f"❌ Erreur init client: {e}")
            raise

    def _load_collections(self):
        """Charge les deux collections (si elles existent)"""
        try:
            # 1. Charger la collection Produits
            try:
                self.product_collection = self.client.get_collection(self.PRODUCT_COLLECTION_NAME)
                logger.info(f"📚 Collection Produits '{self.PRODUCT_COLLECTION_NAME}' chargée.")
            except Exception:
                logger.warning(f"⚠️ Collection Produits '{self.PRODUCT_COLLECTION_NAME}' introuvable.")

            # 2. Charger la collection Ingrédients
            try:
                self.ingredient_collection = self.client.get_collection(self.INGREDIENT_COLLECTION_NAME)
                logger.info(f"🧪 Collection Ingrédients '{self.INGREDIENT_COLLECTION_NAME}' chargée.")
            except Exception:
                logger.warning(f"⚠️ Collection Ingrédients '{self.INGREDIENT_COLLECTION_NAME}' introuvable.")

        except Exception as e:
            logger.error(f"Erreur globale chargement collections: {e}")

    def _query_collection(self, 
                          collection, 
                          query: str, 
                          n_results: int, 
                          where_filter: Optional[Dict], 
                          score_threshold: float) -> List[Dict[str, Any]]:
        """
        Méthode générique interne pour interroger n'importe quelle collection
        """
        if not collection:
            logger.error("Tentative de recherche sur une collection non chargée.")
            return []

        try:
            results = collection.query(
                query_texts=[query],
                n_results=n_results,
                where=where_filter,
                include=["documents", "metadatas", "distances"]
            )

            documents_with_scores = []
            if results["documents"] and len(results["documents"][0]) > 0:
                for i, (doc, metadata, distance) in enumerate(zip(
                    results["documents"][0],
                    results["metadatas"][0],
                    results["distances"][0]
                )):
                    # Conversion distance -> similarité (0 à 1)
                    similarity_score = 1 / (1 + distance)

                    if similarity_score >= score_threshold:
                        documents_with_scores.append({
                            "content": doc,
                            "metadata": metadata,
                            "similarity_score": round(similarity_score, 4),
                            "rank": i + 1,
                            "source_collection": collection.name # Utile pour savoir d'où ça vient
                        })
            
            return documents_with_scores

        except Exception as e:
            logger.error(f"Erreur recherche dans {collection.name}: {e}")
            return []

    # --- MÉTHODES PUBLIQUES ---

    def search_products(self, query: str, n_results: int = 5, min_score: float = 0.4) -> List[Dict[str, Any]]:
        """Recherche uniquement dans les fiches PRODUITS"""
        logger.info(f"🔍 Recherche Produits: '{query}'")
        return self._query_collection(
            self.product_collection, query, n_results, None, min_score
        )

    def search_ingredients(self, query: str, n_results: int = 5, min_score: float = 0.4) -> List[Dict[str, Any]]:
        """Recherche uniquement dans la base INGRÉDIENTS"""
        logger.info(f"🔬 Recherche Ingrédients: '{query}'")
        return self._query_collection(
            self.ingredient_collection, query, n_results, None, min_score
        )

    def search_hybrid(self, query: str) -> Dict[str, List]:
        """
        Recherche simultanée dans les deux bases pour une vue complète
        Utile pour le RAG : on veut savoir de quel produit on parle ET ce que font ses ingrédients.
        """
        return {
            "products": self.search_products(query, n_results=3),
            "ingredients": self.search_ingredients(query, n_results=3)
        }

    def get_context_for_llm(self, query: str, max_chars: int = 4000) -> str:
        """
        Construit un contexte enrichi combinant Produits et Ingrédients
        """
        # 1. On cherche les produits pertinents
        product_docs = self.search_products(query, n_results=3, min_score=0.35)
        
        # 2. On cherche les informations d'ingrédients (si la requête contient des noms chimiques)
        ingredient_docs = self.search_ingredients(query, n_results=3, min_score=0.35)

        context_parts = []
        
        # Section Produits
        if product_docs:
            context_parts.append("=== INFORMATIONS PRODUITS ===")
            for doc in product_docs:
                context_parts.append(f"Produit: {doc['metadata'].get('entity_name', 'Inconnu')}\nDonnées: {doc['content']}\n---")

        # Section Ingrédients
        if ingredient_docs:
            context_parts.append("\n=== INFORMATIONS INGRÉDIENTS (Scientifique) ===")
            for doc in ingredient_docs:
                context_parts.append(f"Ingrédient: {doc['metadata'].get('ingredient_name', 'Inconnu')}\nPropriétés: {doc['content']}\n---")

        full_context = "\n".join(context_parts)
        
        if not full_context:
            return "Aucune information pertinente trouvée dans la base de connaissances."
            
        return full_context[:max_chars]