from fastapi import FastAPI
from pydantic import BaseModel
from main import main_pipeline  # ton fichier qui contient la fonction

# Définir le modèle de requête
class QuestionRequest(BaseModel):
    question: str

# Définir le modèle de réponse
class AnswerResponse(BaseModel):
    response: str 

# Initialiser FastAPI
app = FastAPI(title="Cosmetic QA API")

# Route POST pour poser une question
@app.post("/ask", response_model=AnswerResponse)
def ask_question(request: QuestionRequest):
    question = request.question
    # Appeler ta fonction principale
    answer = main_pipeline(question)
    return {"response": answer}
