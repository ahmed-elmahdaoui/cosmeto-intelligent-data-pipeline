import streamlit as st
import time
import base64
from datetime import datetime
import google.generativeai as genai
from google.generativeai.client import configure
from google.generativeai.generative_models import GenerativeModel
from groq import Groq
from fpdf import FPDF
import re
import tempfile
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
# --- IMPORT DU RETRIEVER (NOUVEAU) ---
from rag.retriever import DocumentRetriever
from main import main_pipeline

# ========================= CONFIG =========================
st.set_page_config(
    page_title="Cosmétovigilance RAG",
    layout="centered",
    initial_sidebar_state="expanded",
    menu_items=None
)

# ========================= CSS =========================
st.markdown("""
<style>
    .main > div {padding-top: 1rem;}
    section[data-testid="stSidebar"] {background: #ffffff; border-right: 1px solid #eee;}
    .logo-text {font-size: 2.8rem; font-weight: 900; background: linear-gradient(135deg, #000, #333);
                -webkit-background-clip: text; -webkit-text-fill-color: transparent;}
    h1 {text-align: center; font-weight: 800; color: #000;}
    [data-testid="userMessage"] {background: #000 !important; color: white !important;}
    .source-badge {background: #e0e0e0; color: #333; padding: 4px 10px; border-radius: 15px;
                   font-size: 0.75rem; display: inline-block; margin: 2px; border: 1px solid #ccc;}
    .pdf-btn {
        background: #000; color: white; padding: 12px 20px; border-radius: 12px;
        text-align: center; font-weight: bold; text-decoration: none; display: block;
    }
</style>
""", unsafe_allow_html=True)

# ========================= SESSION STATE =========================
if "messages" not in st.session_state:
    st.session_state.messages = []

# ========================= API KEYS =========================
try:
    GEMINI_API_KEY = st.secrets["GEMINI_API_KEY"]
    GROQ_API_KEY = st.secrets["GROQ_API_KEY"]
except:
    # Valeurs par défaut (À REMPLACER PAR LES VÔTRES SI NON SECRETS)
    GEMINI_API_KEY = "VOTRE_CLE_GEMINI_ICI" 
    GROQ_API_KEY = "VOTRE_CLE_GROQ_ICI"

configure(api_key=GEMINI_API_KEY)
groq_client = Groq(api_key=GROQ_API_KEY)

# ========================= CHARGEMENT RETRIEVER (CACHE) =========================
@st.cache_resource
def load_retriever():
    """Charge la base vectorielle une seule fois pour optimiser la vitesse"""
    try:
        return DocumentRetriever(persist_directory="storage/chroma_db")
    except Exception as e:
        st.error(f"Erreur critique chargement base de données: {e}")
        return None

retriever = load_retriever()

# ========================= FONCTIONS RAG & APIs =========================

def get_rag_local(question: str):
    """
    1. Cherche dans ChromaDB (Produits + Ingrédients)
    2. Construit un prompt avec le contexte
    3. Utilise Groq (Llama 3) pour formuler la réponse
    """
    if not retriever:
        return {"answer": "Erreur: La base de données n'est pas chargée.", "sources": [], "model": "Erreur"}

    # 1. Récupération du contexte
    context_text = retriever.get_context_for_llm(question)
    
    # 2. Récupération des métadonnées pour l'affichage des sources
    raw_results = retriever.search_hybrid(question)
    
    # Extraction propre des noms de fichiers sources (dédublonnés)
    sources_list = []
    
    # Sources Produits
    if raw_results.get("products"):
        for doc in raw_results["products"]:
            src = doc['metadata'].get('source', 'Inconnu')
            if src not in sources_list: sources_list.append(src)
            
    # Sources Ingrédients
    if raw_results.get("ingredients"):
        for doc in raw_results["ingredients"]:
            src = doc['metadata'].get('ingredient_name', doc['metadata'].get('source', 'Ingrédient'))
            if src not in sources_list: sources_list.append(src)

    # 3. Génération de la réponse via LLM (On utilise Groq car c'est rapide pour le RAG)
    try:
        system_prompt = f"""Tu es un expert en réglementation cosmétique (Maroc & Europe).
        Utilise UNIQUEMENT le contexte suivant pour répondre à la question.
        Si la réponse n'est pas dans le contexte, dis "Je ne trouve pas cette information dans mes documents internes".
        Cite tes sources si possible.
        
        CONTEXTE :
        {context_text}
        """
        
        chat_completion = groq_client.chat.completions.create(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": question}
            ],
            model="llama-3.3-70b-versatile",
            temperature=0.3, # Faible température pour rester factuel
            max_tokens=1024
        )
        answer = chat_completion.choices[0].message.content
        
    except Exception as e:
        answer = f"Erreur lors de la génération : {str(e)}"

    return {"answer": answer, "sources": sources_list[:5], "model": "RAG Local (Llama 3)"}


def get_gemini_answer(question: str):
    try:
        model = GenerativeModel('gemini-2.0-flash')
        prompt = f"Réponds en français ou arabe selon la langue de la question. Sujet : cosmétovigilance.\nQuestion : {question}"
        response = model.generate_content(prompt)
        return {"answer": response.text, "sources": ["Connaissance Web Gemini"], "model": "Gemini 2.0"}
    except Exception as e:
        return {"answer": f"Erreur Gemini : {str(e)}", "sources": [], "model": "Erreur"}


def get_groq_answer(question: str):
    try:
        chat_completion = groq_client.chat.completions.create(
            messages=[{"role": "user", "content": question}],
            model="llama-3.3-70b-versatile",
            temperature=0.3,
            max_tokens=1024
        )
        return {"answer": chat_completion.choices[0].message.content, "sources": ["Connaissance Web Llama 3"], "model": "Groq Llama 3"}
    except Exception as e:
        return {"answer": f"Erreur Groq : {str(e)}", "sources": [], "model": "Erreur"}

# ========================= PDF EXPORT =========================
def export_to_pdf():
    class PDF(FPDF):
        def header(self):
            self.set_fill_color(0, 0, 0)
            self.set_text_color(255, 255, 255)
            self.set_font('Arial', 'B', 16)
            self.cell(0, 15, 'Rapport Cosmetovigilance', 0, 1, 'C', fill=True)
            self.ln(8)

        def footer(self):
            self.set_y(-15)
            self.set_font('Arial', 'I', 9)
            self.set_text_color(130, 130, 130)
            self.cell(0, 10, f'Page {self.page_no()}', 0, 0, 'C')

    pdf = PDF()
    pdf.add_page()
    pdf.set_font('Arial', size=11)

    for msg in st.session_state.messages:
        role = "Utilisateur" if msg["role"] == "user" else "Assistant"
        content = re.sub(r'[^\x00-\x7F]+', '', msg["content"]) # Nettoyage basique pour FPDF standard
        
        pdf.set_font('Arial', 'B', 12)
        pdf.set_text_color(0, 0, 150) if role == "Assistant" else pdf.set_text_color(0, 0, 0)
        pdf.cell(0, 10, f"{role} :", ln=1)
        
        pdf.set_font('Arial', size=11)
        pdf.set_text_color(0, 0, 0)
        pdf.multi_cell(0, 6, content)
        pdf.ln(5)

    with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp_file:
        pdf.output(tmp_file.name)
        return tmp_file.name

# ========================= SIDEBAR =========================
with st.sidebar:
    st.markdown('<div style="text-align:center;padding:2rem 0;"><div class="logo-text">◉</div></div>', unsafe_allow_html=True)
    st.markdown("### Cosmétovigilance RAG")
    st.caption("Expert réglementation cosmétique")
    st.markdown("---")
    
    # Choix du moteur
    engine = st.radio(
        "Source de données :",
        ["RAG Local (Mes Documents)", "Gemini (Web)", "Groq (Web)"],
        index=0,
        captions=["Base de données interne", "Connaissance générale Google", "Connaissance générale Meta"]
    )

    st.markdown("---")
    if st.button("🗑️ Effacer l'historique", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

# ========================= MAIN =========================
st.markdown("# Cosmétovigilance RAG")

# Affichage Historique
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            st.markdown("Sources : " + " ".join([f"<span class='source-badge'>{s}</span>" for s in msg["sources"]]), unsafe_allow_html=True)

# Input Utilisateur
if prompt := st.chat_input("Posez votre question (ex: Quels risques pour le Retinol ?)"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Analyse en cours..."):
            
            # ROUTING DU MOTEUR
            if "RAG Local" in engine:
                resp = main_pipeline(prompt)
            elif "Gemini" in engine:
                resp = get_gemini_answer(prompt)
            else:
                resp = get_groq_answer(prompt)

            # Affichage réponse
            st.markdown(resp["answer"])
            
            # Affichage sources (Uniquement si RAG)
            if resp.get("sources"):
                st.markdown("**Documents utilisés :**")
                badges = "".join([f"<span class='source-badge'>{s}</span>" for s in resp["sources"]])
                st.markdown(badges, unsafe_allow_html=True)

            # Sauvegarde historique
            st.session_state.messages.append({
                "role": "assistant",
                "content": resp["answer"],
                "model": resp.get("model"),
                "sources": resp.get("sources", [])
            })