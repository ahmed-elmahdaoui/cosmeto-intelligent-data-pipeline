# rag/indexing_pipeline.py

import os
import json
import logging
import shutil
from typing import List, Dict, Any, Optional

import sys 


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from rag.indexing import RAGIndexer
from rag.indexing import DocumentIndexer 
from rag.rename_metadata import rename_metadata_files_robust

# Configuration du logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("IndexingPipeline")

# --- FONCTIONS UTILITAIRES ---

def flatten_and_clean_metadata(data, parent_key='', sep='_'):
    """Aplatit les métadonnées imbriquées pour ChromaDB"""
    items = []
    for k, v in data.items():
        new_key = parent_key + k if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_and_clean_metadata(v, new_key + sep, sep=sep).items())
        elif isinstance(v, list):
            clean_list = [str(x) for x in v if x is not None]
            items.append((new_key, ", ".join(clean_list)))
        elif v is None:
            items.append((new_key, ""))  
        else:
            items.append((new_key, v))
    return dict(items)

def process_metadata_folder(folder_path):
    """Nettoie et formate les JSON de métadonnées"""
    if not os.path.exists(folder_path):
        logger.warning(f"⚠️ Dossier métadonnées introuvable : {folder_path}")
        return

    files_processed = 0
    for filename in os.listdir(folder_path):
        if filename.endswith(".json"):
            file_path = os.path.join(folder_path, filename)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    original_data = json.load(f)
                
                cleaned_data = flatten_and_clean_metadata(original_data)
                
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump(cleaned_data, f, indent=4, ensure_ascii=False)
                files_processed += 1
            except Exception as e:
                logger.error(f"❌ Erreur nettoyage {filename}: {e}")
    logger.info(f"✅ Nettoyage métadonnées terminé pour {folder_path} ({files_processed} fichiers)")

def clean_directory(directory_path):
    """Vide un dossier sans le supprimer"""
    if os.path.exists(directory_path):
        for filename in os.listdir(directory_path):
            file_path = os.path.join(directory_path, filename)
            try:
                if os.path.isfile(file_path) or os.path.islink(file_path):
                    os.unlink(file_path)
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                logger.error(f"Erreur suppression {file_path}: {e}")

# --- CLASSE PRINCIPALE ---

class IndexingPipeline:
    def __init__(self, base_storage_path: str = "storage"):
        """
        Pipeline orchestrant l'indexation séparée des Produits et des Ingrédients.
        Args:
            base_storage_path: Racine du dossier de stockage
        """
        self.base_path = base_storage_path
        
        # Configuration des chemins pour les PRODUITS
        self.paths_products = {
            "docs": os.path.join(base_storage_path, "processed_documents/raw_documents/products"),
            "meta": os.path.join(base_storage_path, "processed_documents/metadata/products"),
            "temp_index": os.path.join(base_storage_path, "indexes/products_temp") # Dossier tampon
        }

        # Configuration des chemins pour les INGRÉDIENTS
        self.paths_ingredients = {
            "docs": os.path.join(base_storage_path, "processed_documents/raw_documents/ingredients"),
            "meta": os.path.join(base_storage_path, "processed_documents/metadata/ingredients"),
            "temp_index": os.path.join(base_storage_path, "indexes/ingredients_temp") # Dossier tampon
        }

        self.chroma_db_path = os.path.join(base_storage_path, "chroma_db")
        
        # Initialisation du DocumentIndexer (celui qui parle à ChromaDB)
        self.document_indexer = DocumentIndexer(persist_directory=self.chroma_db_path)
        
        logger.info("🔧 IndexingPipeline initialisé")

    def _process_category(self, category_name: str, paths: Dict[str, str]) -> List[Dict[str, Any]]:
        """
        Traite une catégorie complète (Produits OU Ingrédients).
        1. Nettoie métadonnées
        2. Crée les paires JSON (RAGIndexer)
        3. Charge les résultats en mémoire
        """
        logger.info(f"\n⚙️ --- TRAITEMENT CATÉGORIE : {category_name.upper()} ---")

        # Vérification existence dossiers
        if not os.path.exists(paths["docs"]):
            logger.warning(f"⚠️ Dossier documents introuvable pour {category_name}: {paths['docs']}")
            return []

        # 1. Préparation dossier tampon
        os.makedirs(paths["temp_index"], exist_ok=True)
        clean_directory(paths["temp_index"]) # On part d'un dossier vide pour éviter les mélanges

        # 2. Nettoyage et Renommage Métadonnées
        if os.path.exists(paths["meta"]):
            process_metadata_folder(paths["meta"])
            rename_metadata_files_robust(paths["meta"])

        # 3. Exécution du RAGIndexer (Extraction Texte + Association Meta)
        # Note: On modifie temporairement output_path du RAGIndexer via son instance
        indexer = RAGIndexer(
            documents_path=paths["docs"],
            metadata_path=paths["meta"]
        )
        # Force le chemin de sortie vers notre dossier tampon spécifique
        indexer.output_path = paths["temp_index"]
        if not os.path.exists(indexer.output_path): os.makedirs(indexer.output_path)
        
        indexer.update_index_all()

        # 4. Chargement des JSONs générés en mémoire
        combined_documents = []
        for filename in os.listdir(paths["temp_index"]):
            if filename.endswith(".json"):
                try:
                    with open(os.path.join(paths["temp_index"], filename), 'r', encoding='utf-8') as f:
                        doc_data = json.load(f)
                        combined_documents.append(doc_data)
                except Exception as e:
                    logger.error(f"Erreur lecture JSON intermédiaire {filename}: {e}")

        logger.info(f"✅ {len(combined_documents)} documents {category_name} prêts pour vectorisation.")
        return combined_documents

    def run_complete_pipeline(self):
        """
        Orchestre tout le processus : Produits -> DB, Ingrédients -> DB
        """
        logger.info("🚀 DÉMARRAGE DU PIPELINE D'INDEXATION GLOBAL")

        # --- PHASE 1 : PRODUITS ---
        product_docs = self._process_category("Produits", self.paths_products)
        if product_docs:
            logger.info("💾 Indexation vectorielle des PRODUITS...")
            # Appel de la méthode spécifique du nouveau DocumentIndexer
            self.document_indexer.index_products(product_docs, reset=True)
        else:
            logger.warning("Aucun produit à indexer.")

        # --- PHASE 2 : INGRÉDIENTS ---
        ingredient_docs = self._process_category("Ingrédients", self.paths_ingredients)
        if ingredient_docs:
            logger.info("💾 Indexation vectorielle des INGRÉDIENTS...")
            # Appel de la méthode spécifique du nouveau DocumentIndexer
            self.document_indexer.index_ingredients(ingredient_docs, reset=True)
        else:
            logger.warning("Aucun ingrédient à indexer (c'est normal si le dossier est vide).")

        logger.info("\n🎉 PIPELINE TERMINÉ. La base de connaissances est à jour.")

    def get_status(self):
        """Retourne l'état des collections"""
        try:
            return {
                "db_path": self.chroma_db_path,
                "collections": [c.name for c in self.document_indexer.client.list_collections()]
            }
        except Exception:
            return {"status": "Error retrieving status"}

# --- EXÉCUTION ---
if __name__ == "__main__":
    print("=" * 60)
    print("🚀 PIPELINE RAG DOUBLE-FLUX (PRODUITS & INGRÉDIENTS)")
    print("=" * 60)
    
    # Configuration par défaut
    pipeline = IndexingPipeline(base_storage_path="storage")
    
    # Affichage des chemins détectés pour info
    print(f"📁 Dossier Docs Produits : {pipeline.paths_products['docs']}")
    print(f"📁 Dossier Docs Ingrédients : {pipeline.paths_ingredients['docs']}")
    
    confirm = input("\n▶️ Lancer l'indexation complète (Cela écrasera la base actuelle) ? (o/n): ")
    
    if confirm.lower() in ['o', 'oui', 'y', 'yes']:
        pipeline.run_complete_pipeline()
        print("\n📊 État final de la base :")
        print(pipeline.get_status())