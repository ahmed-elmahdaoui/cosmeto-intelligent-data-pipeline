"""Rôle: Définition des Items Scrapy.
Expose `RawDocumentItem` comme format brut unifié pour les documents collectés.

Exemple:
	from crawlers.items import RawDocumentItem

	item = RawDocumentItem(
		type_document="pdf",
		contenu_document="Texte extrait...",
		tables_qui_possible_remplir=["produit", "ingredient"],
		meta={
			"source_url": "https://exemple.tld/doc.pdf",
			"filename": "doc.pdf",
			"content_type": "application/pdf",
			"fetch_timestamp": "2025-11-08T12:00:00Z",
			"sha256": "<hash>"
		}
	)
"""
import scrapy


class RawDocumentItem(scrapy.Item):
	"""Schéma minimal unifié pour un document brut.

	Champs:
	- type_document: Nature du fichier (pdf, html, csv, txt, doc, xls, autre)
	- path_document: Chemin local vers le fichier sauvegardé (peut être None si non-sauvegardé)
	- tables_qui_possible_remplir: liste de tables/domaines potentiellement extractibles
	- meta: métadonnées (source_url, filename, content_type, fetch_timestamp, sha256)

	NOTE: Le champ 'contenu_document' a été retiré pour alléger le contrat. Le texte
	peut être ré-extrait downstream à partir de path_document selon le type.
	"""
	type_document = scrapy.Field()
	path_document = scrapy.Field()
	tables_qui_possible_remplir = scrapy.Field()
	meta = scrapy.Field()
