"""
Spider Scrapy pour récupérer les informations de produits cosmétiques
depuis Ulta.com.

Sauvegarde le contenu en texte brut sous :
storage/raw_documents/products/<nom_sanitized>/

Usage:
    scrapy crawl document_search_spider -a product="Shampoo Plus"
    scrapy crawl document_search_spider -a product="Retinol Serum" -a storage_dir="custom/path"

Auteur: MouaadErrougbani
Date: 2025-11-12
"""


import scrapy
import os
import json
from bs4 import BeautifulSoup


class DocumentSearchSpider(scrapy.Spider):
    name = "document_search_spider"
    
    def _sanitize(self, name: str) -> str:
        """
        Nettoie un nom pour l'utiliser comme nom de dossier.
        """
        import re
        return re.sub(r'[^\w\s-]', '', name.strip()).replace(' ', '_').lower()

    custom_settings = {
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'ROBOTSTXT_OBEY': False,
        'DOWNLOAD_DELAY': 1.5,
        'RANDOMIZE_DOWNLOAD_DELAY': True,
        'CONCURRENT_REQUESTS': 3,
        'COOKIES_ENABLED': True,
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
            "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
        },
        "TWISTED_REACTOR": "twisted.internet.asyncioreactor.AsyncioSelectorReactor",
        "PLAYWRIGHT_LAUNCH_OPTIONS": {"headless": True},
    }

    def __init__(self, product="deodorant", storage_dir=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.product = product.strip()
        self.base_url = "https://world.openbeautyfacts.org"
        self.storage_root = storage_dir or "storage/processed_documents/raw_documents/"
        # Créer dossier pour tous les produits
        self.output_dir = os.path.join(self.storage_root, "products")
        os.makedirs(self.output_dir, exist_ok=True)
        # Nom du fichier basé sur le produit (espaces => underscores)
        product_sanitized = self._sanitize(self.product)
        self.output_file = os.path.join(self.output_dir, f"{product_sanitized}.txt")
        self.logger.info(f"Fichier cible : {self.output_file}")

    def start_requests(self):
        """Entry point for the spider"""
        search_url = f"{self.base_url}/cgi/search.pl?search_terms={self.product}&search_simple=1&action=process"
        self.logger.info(f"Démarrage recherche OpenBeautyFacts pour : {self.product}")
        yield scrapy.Request(
            search_url,
            callback=self.parse_search,
            meta={
                "playwright": True,
                "playwright_include_page": True,
                "playwright_page_methods": [
                    ("wait_for_load_state", "networkidle"),
                    ("wait_for_timeout", 3000),  # Attendre 3 secondes pour le chargement complet
                ],
            }
        )

    def parse_search(self, response):
        """Parse search results and follow only the first product link"""
        self.logger.info(f"Page de recherche chargée : {response.url}")
        
        # Chercher les liens de produits
        product_links = response.css("a[href*='/product/']::attr(href)").getall()
        
        if not product_links:
            self.logger.warning(f"Aucun produit trouvé pour : {self.product}")
            # Sauvegarder quand même la page de recherche comme search_results.txt
            self._save_search_results(response)
            return

        self.logger.info(f"Trouvé {len(product_links)} lien(s) de produits - Prise du premier seulement")
        
        # Prendre seulement le PREMIER lien
        first_link = product_links[0]
        product_url = response.urljoin(first_link)
        
        self.logger.info(f"Scraping du premier produit : {product_url}")
        yield scrapy.Request(
            product_url,
            callback=self.parse_product,
            meta={
                "playwright": True,
                "playwright_include_page": True,
                "playwright_page_methods": [
                    ("wait_for_load_state", "networkidle"),
                    ("wait_for_timeout", 3000),  # Attendre le chargement complet
                ],
            }
        )

    def parse_product(self, response):
        """Parse individual product page and save as search_results.txt"""
        self.logger.info(f"Page produit chargée : {response.url}")
        
        # Extraire uniquement le texte (pas de HTML)
        soup = BeautifulSoup(response.text, "lxml")
        
        # Supprimer les éléments script et style
        for script in soup(["script", "style"]):
            script.decompose()
        
        # Extraire le texte proprement
        plain_text = soup.get_text(separator="\n", strip=True)
        
        # Nettoyer le texte : optimisé pour LLM
        lines = plain_text.split('\n')
        cleaned_lines = []
        for line in lines:
            line = line.strip()
            if line and len(line) > 3:  # Ignorer les lignes trop courtes
                # Normaliser les espaces multiples
                import re
                line = re.sub(r'\s+', ' ', line)
                cleaned_lines.append(line)
        
        # Joindre avec des doubles retours pour séparer les sections
        final_text = '\n\n'.join(cleaned_lines)
        
        # Créer les métadonnées
        from datetime import datetime
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        metadata = f"product_query: {self.product}\nsource_url: {response.url}\ntimestamp: {timestamp}\npage_type: product_detail\ncontent_length: {len(final_text)}\n\n"
        
        # Combiner métadonnées et contenu
        content = metadata + final_text
        
        # Sauvegarder dans le fichier avec le nom du produit
        with open(self.output_file, "w", encoding="utf-8") as f:
            f.write(content)
        
        self.logger.info(f"Produit sauvegardé : {self.output_file} ({len(final_text)} caractères de contenu)")

    def extract_product_name(self, response):
        """Extract product name"""
        name = response.css("h1::text").get()
        if not name:
            name = response.css(".title::text, h2.product_name::text").get()
        return name.strip() if name else "Unknown"
    
    def _save_search_results(self, response):
        """Sauvegarde la page de recherche si aucun produit n'est trouvé"""
        soup = BeautifulSoup(response.text, "lxml")
        
        # Supprimer les éléments script et style
        for script in soup(["script", "style"]):
            script.decompose()
        
        plain_text = soup.get_text(separator="\n", strip=True)
        
        # Créer métadonnées
        from datetime import datetime
        timestamp = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")
        metadata = f"product_query: {self.product}\nsource_url: {response.url}\ntimestamp: {timestamp}\npage_type: search_results\ncontent_length: {len(plain_text)}\n\n"
        
        content = metadata + plain_text
        
        with open(self.output_file, "w", encoding="utf-8") as f:
            f.write(content)
        
        self.logger.info(f"Page de recherche sauvegardée : {self.output_file}")

    def extract_barcode(self, response):
        """Extract barcode"""
        barcode = response.css("span[property='food:code']::text").get()
        if not barcode:
            # Look in text
            barcode_text = response.css("*:contains('Barcode')").xpath("following-sibling::text()").get()
            if barcode_text:
                barcode = barcode_text.strip()
        return barcode.strip() if barcode else None

    def extract_categories(self, response):
        """Extract categories"""
        categories = response.css("a[href*='/facets/categories/']::text").getall()
        return [c.strip() for c in categories if c.strip() and len(c.strip()) > 2]

    def extract_labels(self, response):
        """Extract labels"""
        labels = response.css("a[href*='/facets/labels/']::text").getall()
        return [l.strip() for l in labels if l.strip() and len(l.strip()) > 2]

    def extract_quantity(self, response):
        """Extract quantity"""
        quantity = response.css("span[property='food:quantity']::text").get()
        if not quantity:
            quantity = response.xpath("//text()[contains(., 'Quantity:')]/following-sibling::text()").get()
        return quantity.strip() if quantity else None

    def extract_brands(self, response):
        """Extract brands"""
        brands = response.css("a[href*='/facets/brands/']::text").getall()
        return [b.strip() for b in brands if b.strip()]

    def extract_ingredients_text(self, response):
        """Extract ingredients as raw text"""
        # Try multiple selectors
        selectors = [
            "#ingredients_list::text",
            "div.ingredients_text::text",
            "span[property='food:ingredientListText']::text",
            "#panel_ingredients_content .panel_text::text",
        ]
        
        for selector in selectors:
            text = response.css(selector).get()
            if text and len(text.strip()) > 10:
                return text.strip()
        
        # Try getting all text from ingredients section
        ingredients_div = response.css("#panel_ingredients_content, div[id*='ingredient']").get()
        if ingredients_div:
            # Extract text from HTML
            text_parts = response.css("#panel_ingredients_content ::text, div[id*='ingredient'] ::text").getall()
            text = " ".join([t.strip() for t in text_parts if t.strip() and len(t.strip()) > 2])
            if len(text) > 20:
                return text
        
        return None

    def extract_ingredients_list(self, response):
        """Extract ingredients as a list"""
        # Try structured data
        ingredients = response.css("li[itemprop='ingredient']::text, span[itemprop='ingredient']::text").getall()
        if ingredients:
            return [i.strip() for i in ingredients if i.strip()]
        
        # Try list items in ingredients section
        ingredients = response.css("#panel_ingredients_content li::text, div[id*='ingredient'] li::text").getall()
        if ingredients:
            cleaned = [i.strip() for i in ingredients if i.strip() and len(i.strip()) > 2]
            # Filter out help text
            filtered = [i for i in cleaned if not any(x in i.lower() for x in ['edit this', 'add new', 'help', 'we need'])]
            if filtered:
                return filtered
        
        return []

    def format_product_data(self, data):
        """Format product data as readable text"""
        lines = []
        lines.append(f"URL: {data['url']}\n")
        lines.append(f"Product Name: {data['product_name']}\n")
        
        if data['barcode']:
            lines.append(f"Barcode: {data['barcode']}\n")
        
        if data['quantity']:
            lines.append(f"Quantity: {data['quantity']}\n")
        
        if data['brands']:
            lines.append(f"\n=== BRANDS ===\n")
            for brand in data['brands']:
                lines.append(f"- {brand}\n")
        
        if data['categories']:
            lines.append(f"\n=== CATEGORIES ===\n")
            for cat in data['categories']:
                lines.append(f"- {cat}\n")
        
        if data['labels']:
            lines.append(f"\n=== LABELS ===\n")
            for label in data['labels']:
                lines.append(f"- {label}\n")
        
        lines.append(f"\n=== INGREDIENTS ===\n")
        if data['ingredients_text']:
            lines.append(f"{data['ingredients_text']}\n")
        elif data['ingredients_list']:
            for ing in data['ingredients_list']:
                lines.append(f"- {ing}\n")
        else:
            lines.append("No ingredients information available for this product.\n")
            lines.append("This product may be incomplete in the OpenBeautyFacts database.\n")
        
        return "".join(lines)