"""Rôle: Pipelines Scrapy.
Ici `DeduplicateByHashPipeline` filtre les doublons d'items selon `meta.sha256`.

Exemple rapide:
    from crawlers.items import RawDocumentItem
    from crawlers.pipelines import DeduplicateByHashPipeline
    import types

    pipeline = DeduplicateByHashPipeline()
    spider = types.SimpleNamespace(logger=types.SimpleNamespace(info=print))
    item = RawDocumentItem(meta={"sha256": "abc"})
    pipeline.process_item(item, spider)   # passe
    try:
        pipeline.process_item(item, spider)  # lève DropItem (doublon)
    except Exception as e:
        print("drop:", e)
"""


# crawlers/pipelines.py
import os
import requests
from urllib.parse import urlparse
from pathlib import Path

class DocumentDownloadPipeline:
    def process_item(self, item, spider):
        base_dir = Path("storage/raw_documents")
        if "product" in item:
            folder_name = item["product"]
            type_folder = "products_docs"
        elif "ingredient" in item:
            folder_name = item["ingredient"]
            type_folder = "ingredients_docs"
        else:
            return None 

        target_dir = base_dir / type_folder / folder_name
        target_dir.mkdir(parents=True, exist_ok=True)

        url_path = urlparse(item["document_url"]).path
        filename = os.path.basename(url_path) or f"document.pdf"
        filepath = target_dir / filename

        try:
            resp = requests.get(item["document_url"], timeout=15)
            resp.raise_for_status()
            with open(filepath, "wb") as f:
                f.write(resp.content)
        except:
            return None

        item["local_path"] = str(filepath)
        return item
