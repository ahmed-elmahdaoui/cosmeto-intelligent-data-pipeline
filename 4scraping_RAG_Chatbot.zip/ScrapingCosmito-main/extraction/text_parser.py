# Rôle: Parsing/segmentation de texte (nettoyage, chunking, normalisation).
# Prépare des unités de texte pour l’extraction et l’indexation.
# Exemple:
#   from extraction.text_parser import chunk_text
#   chunks = chunk_text("long texte...", max_tokens=500)
def parse_text(raw_text: str) -> str:
    """Nettoyer texte: retirer espaces multiples, tabulations, sauts de ligne inutiles"""
    return " ".join(raw_text.split())
