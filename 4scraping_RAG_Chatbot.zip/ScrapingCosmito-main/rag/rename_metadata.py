import os
import json
import re

import sys 
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
def find_path_in_json(data):
    """
    Cherche récursivement ou dans les clés plates une valeur qui ressemble à un chemin de fichier.
    Retourne le premier chemin trouvé.
    """
    # Liste des clés probables à vérifier en priorité
    potential_keys = [
        "source_metadata_source_files", 
        "source_files", 
        "primary_source", 
        "source_metadata_primary_source",
        "source_metadata" # Si c'est encore imbriqué
    ]

    # 1. Vérification directe des clés connues
    for key in potential_keys:
        val = data.get(key)
        if val:
            # Si c'est une liste, on prend le premier élément
            if isinstance(val, list) and len(val) > 0:
                return str(val[0])
            # Si c'est un dictionnaire (cas non aplati), on cherche dedans
            if isinstance(val, dict):
                res = find_path_in_json(val)
                if res: return res
            # Si c'est une string qui ressemble à un chemin
            if isinstance(val, str) and ("storage" in val or "products" in val):
                return val

    # 2. Si non trouvé, on scanne TOUTES les valeurs du dictionnaire
    for key, val in data.items():
        if isinstance(val, str) and ("storage" in val or "\\" in val or "/" in val):
            # On vérifie si ça ressemble au chemin qu'on cherche
            if "products" in val:
                return val
    
    return None

def rename_metadata_files_robust(folder_path):
    if not os.path.exists(folder_path):
        print(f"❌ Le dossier n'existe pas : {folder_path}")
        return

    print(f"📂 Analyse du dossier : {folder_path}")
    
    renamed_count = 0
    errors = 0
    skipped = 0

    for filename in os.listdir(folder_path):
        if filename.endswith(".json"):
            old_file_path = os.path.join(folder_path, filename)
            
            try:
                with open(old_file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)

                # --- ÉTAPE 1 : Trouver le chemin ---
                source_path = find_path_in_json(data)

                if not source_path:
                    # Debug : Afficher les clés du premier fichier échoué pour comprendre
                    if errors == 0: 
                        print(f"⚠️ DEBUG - Clés disponibles dans {filename}: {list(data.keys())}")
                    print(f"⚠️ Ignoré (Chemin introuvable) : {filename}")
                    skipped += 1
                    continue

                # --- ÉTAPE 2 : Extraire la catégorie ---
                # Normaliser les slashs
                normalized_path = source_path.replace('\\', '/')
                
                # On cherche le dossier qui est APRES "products"
                # Ex: storage/raw_documents/products/Face_Serum/search.txt
                parts = normalized_path.split('/')
                
                category_name = None
                
                if "products" in parts:
                    try:
                        idx = parts.index("products")
                        # La catégorie est l'élément juste après 'products'
                        if idx + 1 < len(parts):
                            category_name = parts[idx + 1]
                    except ValueError:
                        pass
                
                # Fallback : Si "products" n'est pas trouvé, on essaie par position (souvent index 3 ou 4)
                if not category_name and len(parts) >= 4:
                     # Supposons structure standard: storage/processed/products/Category
                     category_name = parts[3] 

                if not category_name:
                    print(f"⚠️ Impossible d'extraire la catégorie de : {normalized_path}")
                    skipped += 1
                    continue

                # --- ÉTAPE 3 : Renommer ---
                # Nettoyage du nom
                safe_name = re.sub(r'[^\w\-_]', '', category_name)
                
                # Si le nom est vide ou bizarre, on saute
                if not safe_name or len(safe_name) < 2:
                     print(f"⚠️ Nom de catégorie invalide extrait ({safe_name}) pour {filename}")
                     skipped += 1
                     continue

                new_filename = f"metadata_{safe_name}.json"
                new_file_path = os.path.join(folder_path, new_filename)

                # Éviter de renommer si le nom est identique
                if filename == new_filename:
                    continue

                # Si le fichier cible existe déjà, on ajoute un suffixe pour ne pas écraser
                if os.path.exists(new_file_path):
                    # print(f"ℹ️ Le fichier {new_filename} existe déjà. On garde l'original.")
                    skipped += 1
                    continue

                # Fermer le fichier avant renommage (sécurité Windows)
                # Note: 'with open' le ferme automatiquement à la fin du bloc, donc c'est bon ici.
                
                # Renommage
                os.rename(old_file_path, new_file_path)
                print(f"✅ Renommé : {filename} -> {new_filename}")
                renamed_count += 1

            except Exception as e:
                print(f"❌ Erreur sur {filename} : {str(e)}")
                errors += 1

    print("-" * 30)
    print(f"🎉 Terminé !")
    print(f"✅ Renommés : {renamed_count}")
    print(f"⚠️ Ignorés/Sautés : {skipped}")
    print(f"❌ Erreurs : {errors}")
