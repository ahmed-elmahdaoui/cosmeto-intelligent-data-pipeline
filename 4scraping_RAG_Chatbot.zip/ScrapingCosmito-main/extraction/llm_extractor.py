# Rôle: Extraction pilotée par LLM à partir de texte bruts/segments.
# Utilise des templates Jinja de `prompts/` pour produire des enregistrements conformes aux schémas.
# Exemple:
#   from extraction.llm_extractor import extract_case_report
#   data = extract_case_report(chunks, template="prompts/extract_case_report.jinja")
