# Rôle: Abstraction fournisseur d’_embeddings_ (OpenAI, local, etc.).
# Fournit une API unifiée pour encoder du texte et renvoyer des vecteurs.
# Exemple:
#   from rag.embedding_provider import embed
#   vec = embed("Niacinamide benefits")
import os
from typing import List, Optional
import numpy as np
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EmbeddingProvider:
    def __init__(self, model_name: str = "all-MiniLM-L6-v2"):
        """
        Fournisseur d'embeddings pour la recherche sémantique
        Args:
            model_name: Modèle SentenceTransformer à utiliser
        """
        self.model_name = model_name
        self.model = None
        self._load_model()

    def _load_model(self):
        """Charge le modèle d'embedding"""
        try:
            logger.info(f"Chargement du modèle d'embedding: {self.model_name}")
            self.model = SentenceTransformer(self.model_name)
            logger.info("Modèle d'embedding chargé avec succès")
        except Exception as e:
            logger.error(f"Erreur lors du chargement du modèle: {e}")
            raise

    def get_embeddings(self, texts: List[str]) -> List[List[float]]:
        """
        Génère les embeddings pour une liste de textes
        Args:
            texts: Liste des textes à vectoriser
        Returns:
            Liste des embeddings
        """
        if not self.model:
            self._load_model()

        try:
            embeddings = self.model.encode(texts)
            return embeddings.tolist()
        except Exception as e:
            logger.error(f"Erreur lors de la génération des embeddings: {e}")
            return []

    def get_embedding(self, text: str) -> List[float]:
        """
        Génère l'embedding pour un seul texte
        Args:
            text: Texte à vectoriser
        Returns:
            Embedding du texte
        """
        return self.get_embeddings([text])[0]

# Instance globale pour éviter de recharger le modèle