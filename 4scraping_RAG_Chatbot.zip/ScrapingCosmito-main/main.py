from pipeline_0 import point_end, call_llm
from pipeline_1 import ajouter_rag
from pipeline_2 import get_resultat_rag
from pipeline_3 import reponse_llm
def main_pipeline(question) :
    res = point_end(question, type="Q")
    if res["etat"]:
        ajouter_rag(res)
        qes  = ",".join([i for i in res["products"]]) + ",".join([i for i in res["ingredients"]])
        rag_res = get_resultat_rag(qes)
        final_response = reponse_llm(
            user_question=question,
            # rag_products=rag_res["products"],
            rag_products="",
            rag_ingredients=rag_res["ingredients"]
        ) 
        final_response = final_response["reponse"]
        
    else : 
        prompt = f"""
        Tu es un assistant expert en cosmétiques.

        QUESTION UTILISATEUR :
        ----
        {question}
        ----
        INSTRUCTIONS :
        1. La question ne concerne pas le domaine des cosmétiques.
        2. Répond poliment et informe que tu ne trouves aucun résultat.
        3. Répond dans la même langue que la question (QUESTION UTILISATEUR).
        4. RÉPONDS STRICTEMENT en JSON avec ce format :
        {{
        "etat": false,
        "message": "texte de réponse pour l'utilisateur en la même langue de QUESTION UTILISATEUR"
        }}

        RÉPONSE :
        """

        response = call_llm(
                qes=prompt,
                model="llama-3.1-8b-instant",
                temperature=0,
                max_tokens=60
            )
        final_response = response["message"]
    insert = {"answer" : final_response}
    return insert
