# Rôle: Lecture de documents non-PDF (DOC/DOCX/RTF si requis) et conversion vers texte.
# Complémentaire à `pdf_reader.py` pour couvrir d’autres formats.
# Exemple:
#   from extraction.doc_reader import read_docx
#   texte = read_docx("storage/raw_documents/report.docx")
import docx

def read_doc(file_path: str) -> str:
    doc = docx.Document(file_path)
    text = "\n".join([p.text for p in doc.paragraphs])
    return text
