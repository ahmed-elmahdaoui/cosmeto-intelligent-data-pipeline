python -m venv .venv
source .venv/bin/activate
# Dépendances principales
pip install scrapy scrapy-playwright beautifulsoup4 PyYAML requests python-dotenv
# Installer les navigateurs Playwright
playwright install chromium
# Installer les dépendances système (Linux/Ubuntu)
sudo apt-get update && sudo apt-get install -y \
libatk-1.0-0 libatk-bridge2.0-0 libgconf-2-4 libxkbcommon0 libxss1 \
libgbm1 libnss3 libxrandr2 libpango-1.0-0 libcairo2 fonts-liberation
pip install -r requirements.txt
pip cache purge
python -m pip install google-generativeai
python -m pip install groq
python -m pip install chromadb
pip install streamlit

streamlit run ./cosme_front/app.py











Pour publice le url : gh codespace ports visibility 8001:public
en PowerShelle : 

# Définir l'URL de l'API
$uri = "https://fluffy-guacamole-q7grx7qgg4q4hpq4-8001.app.github.dev/ask"

# Préparer le corps JSON
$body = @{
    question = "Quels rouges à lèvres contiennent de la vitamine E ?"
} | ConvertTo-Json -Compress

# Convertir le JSON en bytes UTF8
$bytes = [System.Text.Encoding]::UTF8.GetBytes($body)

# Envoyer le POST et récupérer la réponse
$response = Invoke-RestMethod -Uri $uri -Method Post -ContentType "application/json" -Body $bytes

# Afficher la réponse
$response.response



et En Termenale de Code space : 

curl -v -X POST "https://fluffy-guacamole-q7grx7qgg4q4hpq4-8001.app.github.dev/ask"   -H "Content-Type: application/json"   -d '{"question":"Quels rouges à lèvres contiennent de la vitamine E ?"}'


# ScrapingCosmito

Projet de scraping pour collecter des données sur les produits cosmétiques et leurs ingrédients depuis différentes sources (OpenBeautyFacts, PubChem, DrugBank).

## 📋 Prérequis

- Python 3.8+
- pip (gestionnaire de paquets Python)

## 🔧 Installation

### 1. Cloner le projet

```bash
git clone https://github.com/MouaadErrougbani/ScrapingCosmito.git
cd ScrapingCosmito
```

### 2. Créer un environnement virtuel (recommandé)

```bash
python -m venv .venv
source .venv/bin/activate  # Linux/Mac
# ou
.venv\Scripts\activate     # Windows
```

### 3. Installer les dépendances

```bash
# Dépendances principales
pip install scrapy scrapy-playwright beautifulsoup4 PyYAML requests python-dotenv

# Installer les navigateurs Playwright
playwright install chromium

# Installer les dépendances système (Linux/Ubuntu)
sudo apt-get update && sudo apt-get install -y \
  libatk-1.0-0 libatk-bridge2.0-0 libgconf-2-4 libxkbcommon0 libxss1 \
  libgbm1 libnss3 libxrandr2 libpango-1.0-0 libcairo2 fonts-liberation
```

## 📁 Structure du projet

```
ScrapingCosmito/
├── crawlers/
│   ├── spiders/
│   │   ├── document_search_spider.py      # Spider pour produits (OpenBeautyFacts)
│   │   └── ingredient_search_spider.py    # Spider pour ingrédients (PubChem/DrugBank)
│   ├── items.py                           # Définition des items Scrapy
│   ├── pipelines.py                       # Pipelines de traitement
│   └── settings.py                        # Configuration Scrapy
├── storage/
│   └── processed_documents/
│       └── raw_documents/
│           ├── products/                  # Résultats produits (.txt)
│           └── ingredients/               # Résultats ingrédients (.txt)
├── run_products.py                        # Script batch pour produits
├── run_ingredients.py                     # Script batch pour ingrédients
├── products.txt                           # Fichier exemple de produits
├── ingredients.txt                        # Fichier exemple d'ingrédients
├── scrapy.cfg                             # Configuration Scrapy
└── README.md
```

## 🚀 Utilisation

### Méthode 1 : Lancer un spider individuellement

#### Pour un produit :
```bash
scrapy crawl document_search_spider -a product="deodorant"
scrapy crawl document_search_spider -a product="vitamin c serum"
```

#### Pour un ingrédient :
```bash
# Avec PubChem (par défaut, recommandé)
scrapy crawl ingredient_search_spider -a ingredient="glycerin"
scrapy crawl ingredient_search_spider -a ingredient="salicylic acid"

# Avec DrugBank (peut être bloqué)
scrapy crawl ingredient_search_spider -a ingredient="retinol" -a source="drugbank"
```

### Méthode 2 : Lancer en batch depuis un fichier

#### Pour plusieurs produits :

1. Créez un fichier `mes_produits.txt` :
```text
deodorant
shampoo
vitamin c serum
retinol cream
hyaluronic acid serum
```

2. Lancez le script :
```bash
python run_products.py mes_produits.txt
```

#### Pour plusieurs ingrédients :

1. Créez un fichier `mes_ingredients.txt` :
```text
glycerin
niacinamide
retinol
salicylic acid
hyaluronic acid
```

2. Lancez le script :
```bash
# Avec PubChem (défaut)
python run_ingredients.py mes_ingredients.txt

# Avec DrugBank
python run_ingredients.py mes_ingredients.txt drugbank
```

## 📤 Résultats

Les résultats sont sauvegardés dans :

```
storage/processed_documents/raw_documents/
├── products/
│   ├── deodorant.txt
│   ├── vitamin_c_serum.txt
│   └── retinol_cream.txt
└── ingredients/
    ├── glycerin.txt
    ├── niacinamide.txt
    └── salicylic_acid.txt
```

**Format des fichiers** :
- Nom de fichier = nom du produit/ingrédient avec underscores
- Espaces remplacés par `_` (exemple : `"vitamin c serum"` → `vitamin_c_serum.txt`)
- Contenu : texte brut avec métadonnées (source, timestamp, etc.)

## 🔍 Sources de données

| Type | Source | Fiabilité | Notes |
|------|--------|-----------|-------|
| **Produits** | OpenBeautyFacts | ✅ Haute | Base de données ouverte |
| **Ingrédients** | PubChem | ✅ Haute | API gratuite, pas de blocage |
| **Ingrédients** | DrugBank | ⚠️ Moyenne | Peut bloquer l'accès (403) |

## 🛠️ Dépannage

### Erreur Playwright : `libatk-1.0.so.0: cannot open shared object`

Installez les dépendances système :
```bash
playwright install-deps
```

### Erreur : `Scrapy 2.13.4 - no active project`

Le fichier `scrapy.cfg` est manquant. Il devrait contenir :
```ini
[settings]
default = crawlers.settings

[deploy]
project = cosmetodataforge
```

### Erreur 403 avec DrugBank

DrugBank bloque souvent l'accès. Utilisez PubChem à la place :
```bash
scrapy crawl ingredient_search_spider -a ingredient="glycerin" -a source="pubchem"
```

## 📝 Exemples

### Exemple 1 : Scraper 5 produits
```bash
cat > produits_test.txt << EOF
deodorant
shampoo
face cream
body lotion
sunscreen
EOF

python run_products.py produits_test.txt
```

### Exemple 2 : Scraper 3 ingrédients
```bash
cat > ingredients_test.txt << EOF
glycerin
niacinamide
retinol
EOF

python run_ingredients.py ingredients_test.txt
```

## 📊 Statistiques

Les scripts affichent un résumé à la fin :
```
============================================================
📊 RÉSUMÉ
============================================================
✅ Réussis: 5
❌ Échoués: 0
📁 Résultats dans: storage/processed_documents/raw_documents/products/
============================================================
```

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à ouvrir une issue ou une pull request.

## 📄 Licence

MIT License

## 👤 Auteur

**Mouaad Errougbani**

- GitHub: [@MouaadErrougbani](https://github.com/MouaadErrougbani)
- Repository: [ScrapingCosmito](https://github.com/MouaadErrougbani/ScrapingCosmito)