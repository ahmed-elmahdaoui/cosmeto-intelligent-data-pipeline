import os 
from pipeline_0 import call_llm
from rag.retriever import DocumentRetriever


import sys 
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

prompt = """Tu es un module de reformulation pour un système RAG cosmétique.

Transforme la question utilisateur en deux requêtes :
- product_query : type de produit ou marque
- ingredient_query : ingrédient recherché

Retourne UNIQUEMENT ce JSON :

{
  "product_query": "string",
  "ingredient_query": "string",
  "etat": true | false
}

Règles :
- Si la question concerne les cosmétiques → etat=true
- Sinon → champs vides et etat=false
- Aucune réponse métier, aucun texte hors JSON
---
Question :
"""



def get_resultat_rag(resultat) : 
    """
    Docstring for get_resultat_rag
    
    :param resultata: Description
    """
    retriever = DocumentRetriever(persist_directory="storage/chroma_db")
    # le code ici appelle le RAG avec les resultats de la reformulation
    resultat_rag = {}
    # resultat_rag["products"] =retriever.search_products("\n".join([doc for doc in resultat["products"]]), n_results=2)
    resultat_rag["ingredients"] =retriever.search_hybrid(resultat)
    return resultat_rag
