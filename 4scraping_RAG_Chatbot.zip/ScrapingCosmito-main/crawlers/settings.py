"""Rôle: Fichier de configuration Scrapy (paramètres globaux, export JSON, pipelines).
Personnalisation: Variables d'environnement (CRAWL_CONCURRENT_REQUESTS, OUTPUT_PATH, etc.) permettent tuning sans modifier le code.
"""
import os
from pathlib import Path

# Optional: load .env if present (non-fatal if python-dotenv absent)
try:  # lightweight, safe
	from dotenv import load_dotenv  # type: ignore
	load_dotenv()
except Exception:
	pass

# ---------------------------------------------------------------------------
# Dynamic config bootstrap
# Reads YAML (config/base.yaml by default) to populate environment variables
# used by spiders and the async agent subprocess calls, without modifying
# agent code. This lets tuning happen via env overrides or the YAML file.
# ---------------------------------------------------------------------------
import json
try:
	import yaml  # type: ignore
except Exception:
	yaml = None  # graceful fallback if PyYAML absent

CONFIG_PATH = os.getenv("CDFS_CONFIG", "config/base.yaml")
_cfg = {}
if yaml and Path(CONFIG_PATH).exists():
	try:
		with open(CONFIG_PATH, "r", encoding="utf-8") as f:
			_cfg = yaml.safe_load(f) or {}
	except Exception:
		_cfg = {}

paths_cfg = (_cfg.get("paths") or {})
llm_cfg = (_cfg.get("llm") or {})
crawler_cfg = (_cfg.get("crawler") or {})

# Set default env vars only if not already explicitly provided.
def _setdefault_env(key: str, value: str):
	if value is None:
		return
	os.environ.setdefault(key, str(value))

# Paths (used by watchers / file handlers / spiders)
_setdefault_env("RAW_ROOT", paths_cfg.get("raw_documents", "storage/raw_documents/"))
_setdefault_env("PROCESSED_ROOT", paths_cfg.get("processed_documents", "storage/processed_documents/"))
_setdefault_env("JSON_OUTPUT_DIR", paths_cfg.get("json_output", "storage/json_output/"))
_setdefault_env("PROMPTS_DIR", paths_cfg.get("prompts", "prompts/"))
_setdefault_env("LOGS_DIR", paths_cfg.get("logs", "logs/"))

# LLM (agent will look at GEMINI_API_KEY separately; we still expose model/provider for consistency)
_setdefault_env("LLM_MODEL", llm_cfg.get("model"))
_setdefault_env("LLM_PROVIDER", llm_cfg.get("provider"))

# Crawl tuning mirrors YAML values unless overridden by explicit env
_setdefault_env("CRAWL_CONCURRENT_REQUESTS", crawler_cfg.get("concurrent_requests", 8))
_setdefault_env("CRAWL_DOWNLOAD_DELAY", crawler_cfg.get("download_delay", 0.5))
_setdefault_env("CRAWL_RETRY_TIMES", crawler_cfg.get("retry_times", 2))
_setdefault_env("CRAWL_DOWNLOAD_TIMEOUT", crawler_cfg.get("download_timeout", 30))

# Additional agent-relevant concurrency knobs (not used directly by Scrapy but
# provided so subprocess environment contains them for future spiders/extensions)
_setdefault_env("MAX_CONCURRENT_PRODUCTS", 8)
_setdefault_env("MAX_CONCURRENT_DOCS_PER_PRODUCT", 4)
_setdefault_env("LLM_MAX_CONCURRENT", 4)
_setdefault_env("LLM_MAX_RETRIES", 2)
_setdefault_env("SPIDER_TIMEOUT", 180)

# OUTPUT_PATH from config if defined (supports manager + feed export synergy)
output_cfg = (_cfg.get("output") or {})
if output_cfg.get("output_path"):
	_setdefault_env("OUTPUT_PATH", output_cfg.get("output_path"))

# Classification keywords serialized for spiders that may read them via env
classification_keywords = _cfg.get("classification_keywords") or {}
if classification_keywords:
	try:
		_setdefault_env("CLASSIFICATION_KEYWORDS_JSON", json.dumps(classification_keywords))
	except Exception:
		pass

# Par défaut surchargés via env vars ou futur chargeur YAML.
BOT_NAME = "cosmetodataforge"

SPIDER_MODULES = ["crawlers.spiders"]
NEWSPIDER_MODULE = "crawlers.spiders"

ROBOTSTXT_OBEY = False

CONCURRENT_REQUESTS = int(os.getenv("CRAWL_CONCURRENT_REQUESTS", 8))
DOWNLOAD_DELAY = float(os.getenv("CRAWL_DOWNLOAD_DELAY", 0.5))
RETRY_TIMES = int(os.getenv("CRAWL_RETRY_TIMES", 2))
DOWNLOAD_TIMEOUT = int(os.getenv("CRAWL_DOWNLOAD_TIMEOUT", 30))
CONCURRENT_REQUESTS_PER_DOMAIN = int(os.getenv("CRAWL_CONCURRENT_PER_DOMAIN", 8))
CONCURRENT_REQUESTS_PER_IP = int(os.getenv("CRAWL_CONCURRENT_PER_IP", 0))  # 0 = disabled
REACTOR_THREADPOOL_MAXSIZE = int(os.getenv("CRAWL_THREADPOOL_MAXSIZE", 20))

DEFAULT_REQUEST_HEADERS = {
	"User-Agent": os.getenv("CRAWL_USER_AGENT", "CosmetoDataForgeCrawler/0.1"),
}

LOG_LEVEL = os.getenv("CRAWL_LOG_LEVEL", "INFO")

# Optional auto-throttle
AUTOTHROTTLE_ENABLED = os.getenv("CRAWL_AUTOTHROTTLE", "false").lower() == "true"
AUTOTHROTTLE_START_DELAY = float(os.getenv("CRAWL_AUTOTHROTTLE_START", 0.5))
AUTOTHROTTLE_MAX_DELAY = float(os.getenv("CRAWL_AUTOTHROTTLE_MAX", 10.0))
AUTOTHROTTLE_TARGET_CONCURRENCY = float(os.getenv("CRAWL_AUTOTHROTTLE_TARGET", 2.0))

# Export du flux d'items vers un fichier JSON unique.
# Feed output path (after potential YAML/env bootstrap above)
OUTPUT_PATH = os.getenv("OUTPUT_PATH", "outputs/crawl_output.json")
os.makedirs(os.path.dirname(OUTPUT_PATH), exist_ok=True)
FEEDS = {
	OUTPUT_PATH: {
		"format": "json",
		"encoding": "utf-8",
		"indent": 2,
		"overwrite": True,
	}
}
FEED_EXPORT_ENCODING = "utf-8"

# Export uniquement le contrat unifié (ne pas inclure contenu_document)
FEED_EXPORT_FIELDS = [
    "type_document",
    "path_document",
    "tables_qui_possible_remplir",
    "meta",
]

# Enable pipelines
# Pipelines: ensure only registered classes that exist; guard optional ones.
# If stubs aren't implemented yet, comment them or provide them later without
# breaking import resolution for agents.
ITEM_PIPELINES = {}
if os.getenv("ENABLE_DEDUP_PIPE", "false").lower() == "true":
    ITEM_PIPELINES["crawlers.pipelines.DeduplicateByHashPipeline"] = 100  # requires implementation
if os.getenv("ENABLE_AGGREGATE_PIPE", "false").lower() == "true":
    ITEM_PIPELINES["crawlers.pipelines.AggregateByTypePipeline"] = 300  # requires implementation

# End of dynamic settings augmentation

DOWNLOAD_HANDLERS = {
    "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
    "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
}

TWISTED_REACTOR = "twisted.internet.asyncioreactor.AsyncioSelectorReactor"

PLAYWRIGHT_LAUNCH_OPTIONS = {
    "headless": True
}
