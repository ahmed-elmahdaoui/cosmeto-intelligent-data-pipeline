# test_rag_dual.py
import logging

import sys ,os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from rag.retriever import DocumentRetriever

# Configuration pour voir ce qui se passe
logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger("RAGTest")

def print_results(title, results):
    print(f"\n--- {title} ({len(results)} résultats) ---")
    if not results:
        print("   (Aucun résultat trouvé)")
        return

    for i, res in enumerate(results):
        meta = res.get('metadata', {})
        source = meta.get('source', 'Inconnue')
        score = res.get('similarity_score', 0.0)
        content = res.get('content', '')[:100].replace('\n', ' ') # Aperçu court
        
        print(f" {i+1}. [{score:.2f}] {source} | {content}...")

def main():
    print("🚀 INITIALISATION DU RETRIEVER...")
    try:
        retriever = DocumentRetriever(persist_directory="storage/chroma_db")
    except Exception as e:
        print(f"❌ Erreur critique : Impossible de charger la base. Avez-vous indexé ?\n{e}")
        return

    # 1. TEST PRODUITS
    # Remplacez "Crème" par un mot clé présent dans vos PDFs produits
    query_product = "Crème hydratante" 
    print(f"\n🔍 TEST 1 : Recherche PRODUITS pour '{query_product}'")
    results_prod = retriever.search_products(query_product, n_results=2)
    print_results("Résultats Produits", results_prod)

    # 2. TEST INGRÉDIENTS
    # Remplacez "Glycerin" par un ingrédient présent dans vos PDFs ingrédients
    query_ingredient = "Glycerin" 
    print(f"\n🔬 TEST 2 : Recherche INGRÉDIENTS pour '{query_ingredient}'")
    results_ing = retriever.search_ingredients(query_ingredient, n_results=2)
    print_results("Résultats Ingrédients", results_ing)

    # 3. TEST CONTEXTE LLM (HYBRIDE)
    # Une question qui demande les deux infos
    query_hybrid = "Quels sont les effets du Retinol dans la crème visage ?"
    print(f"\n🧠 TEST 3 : Génération de Contexte LLM pour '{query_hybrid}'")
    
    context = retriever.get_context_for_llm(query_hybrid)
    
    print("\n" + "="*40)
    print("APERÇU DU CONTEXTE GÉNÉRÉ POUR LE BOT :")
    print("="*40)
    print(context)
    print("="*40)

if __name__ == "__main__":
    main()