"""
Spider Scrapy pour récupérer les informations d'ingrédients cosmétiques
depuis la base de données EU COSING.

Sauvegarde le contenu en texte brut sous :
storage/raw_documents/ingredients/<nom_sanitized>/

Usage:
    scrapy crawl ingredient_search_spider -a ingredient="niacinamide"
    scrapy crawl ingredient_search_spider -a ingredient="retinol" -a storage_dir="custom/path"

Auteur: MouaadErrougbani
Date: 2025-11-12
"""

import os
import re
from pathlib import Path
from typing import Optional, Dict

import scrapy
from scrapy.http import Response
from bs4 import BeautifulSoup
from scrapy_playwright.page import PageMethod
import asyncio

def extract_html_text(html: str, preserve_newlines=True, normalize_spaces=True) -> str:
    """Extract visible text from HTML."""
    soup = BeautifulSoup(html, "lxml")
    
    # Supprimer les éléments script et style
    for script in soup(["script", "style"]):
        script.decompose()
    
    text = soup.get_text(separator="\n" if preserve_newlines else " ", strip=True)
    if normalize_spaces:
        # Normaliser les espaces tout en préservant les sauts de ligne
        lines = text.split('\n')
        cleaned_lines = [re.sub(r'\s+', ' ', line.strip()) for line in lines if line.strip()]
        text = '\n'.join(cleaned_lines)
    return text


class IngredientSearchSpider(scrapy.Spider):
    """
    Spider pour extraire les données d'ingrédients depuis DrugBank.
    Utilise Playwright pour gérer le JavaScript et attendre le chargement complet.
    Sauvegarde uniquement le texte dans storage/raw_documents/ingredients/
    """

    name = "ingredient_search_spider"
    
    custom_settings = {
        "DOWNLOAD_DELAY": 2.0,
        "CONCURRENT_REQUESTS": 1,
        "RANDOMIZE_DOWNLOAD_DELAY": True,
        "ROBOTSTXT_OBEY": False,  # DrugBank peut bloquer les robots
        "DEFAULT_REQUEST_HEADERS": {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9,fr;q=0.8",
        },
        # Configuration Playwright
        "DOWNLOAD_HANDLERS": {
            "http": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
            "https": "scrapy_playwright.handler.ScrapyPlaywrightDownloadHandler",
        },
        "TWISTED_REACTOR": "twisted.internet.asyncioreactor.AsyncioSelectorReactor",
        "PLAYWRIGHT_LAUNCH_OPTIONS": {
            "headless": True,
            "timeout": 30000,
        },
        "PLAYWRIGHT_DEFAULT_NAVIGATION_TIMEOUT": 30000,
    }

    BASE_URL = "https://go.drugbank.com"

    def __init__(self, ingredient: Optional[str] = None, storage_dir: Optional[str] = None, source: Optional[str] = None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if not ingredient:
            raise scrapy.exceptions.CloseSpider("Paramètre manquant: -a ingredient=<nom_ingredient>")
        
        self.ingredient = ingredient.strip()
        # Déterminer la source (PubChem par défaut, plus fiable)
        self.source = (source or "pubchem").lower()
        
        self.storage_root = storage_dir or "storage/processed_documents/raw_documents/"
        # Créer dossier pour tous les ingrédients
        self.target_dir = Path(self.storage_root) / "ingredients"
        self.target_dir.mkdir(parents=True, exist_ok=True)
        # Nom du fichier basé sur l'ingrédient (espaces => underscores)
        ingredient_sanitized = self._sanitize(self.ingredient)
        self.output_file = self.target_dir / f"{ingredient_sanitized}.txt"
        self.logger.info(f"Source: {self.source.upper()} | Fichier cible : {self.output_file}")


    def _sanitize(self, name: str) -> str:
        """
        Nettoie un nom pour l'utiliser comme nom de dossier.
        Compatible avec DocumentWatcher.get_documents_for_ingredient()
        """
        return re.sub(r'[^\w\s-]', '', name.strip()).replace(' ', '_').lower()

    def _is_drugbank_id(self, ingredient: str) -> bool:
        """
        Vérifie si l'ingrédient est un ID DrugBank (format: DB + chiffres)
        """
        return bool(re.match(r'^DB\d{5,}$', ingredient.strip(), re.IGNORECASE))


    def start_requests(self):
        """Méthode start_requests standard pour compatibilité avec l'agent"""
        
        if self.source == "pubchem":
            # PubChem - recherche HTML directe (plus fiable que l'API)
            search_url = f"https://pubchem.ncbi.nlm.nih.gov/#query={self.ingredient}"
            self.logger.info(f"Recherche PubChem pour '{self.ingredient}'")
            
            yield scrapy.Request(
                url=search_url,
                callback=self.parse_pubchem_search,
                errback=self.handle_error,
                dont_filter=True,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    "playwright_page_methods": [
                        PageMethod("wait_for_load_state", "domcontentloaded"),
                        PageMethod("wait_for_timeout", 3000),
                    ]
                }
            )
        else:
            # DrugBank (peut être bloqué)
            if self._is_drugbank_id(self.ingredient):
                direct_url = f"{self.BASE_URL}/drugs/{self.ingredient}"
                self.logger.info(f"ID DrugBank détecté, téléchargement direct : {direct_url}")
            else:
                direct_url = f"{self.BASE_URL}/unearth/q?searcher=drugs&query={self.ingredient}&button="
                self.logger.info(f"Recherche DrugBank pour '{self.ingredient}': {direct_url}")

            yield scrapy.Request(
                url=direct_url,
                callback=self.parse_page_content,
                errback=self.handle_error,
                dont_filter=True,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    "playwright_page_methods": [
                        PageMethod("wait_for_load_state", "domcontentloaded"),
                        PageMethod("wait_for_timeout", 2000),
                    ]
                }
            )

    def parse_pubchem_search(self, response):
        """Parse PubChem search results"""
        page = response.meta.get("playwright_page")
        
        try:
            # Chercher le premier lien de composé
            compound_link = response.css('a[href*="/compound/"]::attr(href)').get()
            
            if compound_link:
                if not compound_link.startswith("http"):
                    compound_link = f"https://pubchem.ncbi.nlm.nih.gov{compound_link}"
                
                self.logger.info(f"Composé trouvé : {compound_link}")
                
                if page:
                    try:
                        asyncio.get_event_loop().create_task(page.close())
                    except:
                        pass
                
                yield scrapy.Request(
                    url=compound_link,
                    callback=self.parse_pubchem_page,
                    errback=self.handle_error,
                    dont_filter=True,
                    meta={
                        "playwright": True,
                        "playwright_include_page": True,
                        "playwright_page_methods": [
                            PageMethod("wait_for_load_state", "domcontentloaded"),
                            PageMethod("wait_for_timeout", 2000),
                        ]
                    }
                )
            else:
                self.logger.warning("Aucun composé trouvé sur PubChem")
        except Exception as e:
            self.logger.error(f"✗ Erreur parsing recherche PubChem: {e}")
        finally:
            if page:
                try:
                    asyncio.get_event_loop().create_task(page.close())
                except:
                    pass

    def parse_pubchem_page(self, response):
        """Parse PubChem compound page"""
        page = response.meta.get("playwright_page")
        self.logger.info(f"Page PubChem téléchargée : {response.url}")
        
        try:
            # Extraire le contenu principal
            main_content = response.css('#section-Top, .compound-details, main').get()
            
            if main_content:
                cleaned_text = extract_html_text(main_content)
            else:
                soup = BeautifulSoup(response.text, "lxml")
                for tag in soup(['nav', 'header', 'footer', 'script', 'style', 'aside']):
                    try:
                        tag.decompose()
                    except:
                        pass
                cleaned_text = extract_html_text(str(soup))
            
            if not cleaned_text or len(cleaned_text.strip()) < 50:
                self.logger.warning("Contenu PubChem trop court")
                return
            
            content = self._format_for_llm(cleaned_text, response.url)
            self._write_text_file("search_results.txt", content)
            self.logger.info(f"✓ Ingrédient téléchargé avec succès via PubChem")
        except Exception as e:
            self.logger.error(f"✗ Erreur parsing PubChem page: {e}")
        finally:
            if page:
                try:
                    asyncio.get_event_loop().create_task(page.close())
                except:
                    pass



    def parse_page_content(self, response: Response):
        """
        Télécharge + nettoie le contenu (optimisé LLM/RAG)
        """
        page = response.meta.get("playwright_page")

        # --- Gestion spéciale : page de recherche DrugBank ---
        if "button=" in response.url:
            result = response.css('.search-result .hit-link a::attr(href)').get()

            if not result:
                self.logger.warning("Aucun résultat trouvé sur la page de recherche.")
                return

            if not result.startswith("http"):
                result = f"https://go.drugbank.com{result}"

            self.logger.info(f"→ Page résultat trouvée : {result}")

            try:
                asyncio.get_event_loop().create_task(page.close())
            except:
                pass

            yield scrapy.Request(
                url=result,
                callback=self.parse_page_content,
                errback=self.handle_error,
                dont_filter=True,
                meta={
                    "playwright": True,
                    "playwright_include_page": True,
                    "playwright_page_methods": [
                        PageMethod("wait_for_load_state", "domcontentloaded"),
                        PageMethod("wait_for_timeout", 1500),
                    ]
                }
            )
            return

        # --- Ici, on est sur la page finale /drugs/DBxxxx ---
        self.logger.info(f"Page téléchargée : {response.url}")

        try:
            main_content = response.css('#content, main, article, .main-content, .drug-content').get()

            if main_content:
                cleaned_text = extract_html_text(main_content)
            else:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(response.text, "lxml")

                for tag in soup(['nav', 'header', 'footer', 'script', 'style', 'aside',
                                'iframe', 'noscript']):
                    try:
                        tag.decompose()
                    except:
                        pass

                cleaned_text = extract_html_text(str(soup))

            if not cleaned_text or len(cleaned_text.strip()) < 100:
                self.logger.warning("Contenu trop court. Ignoré.")
                return

            content = self._format_for_llm(cleaned_text, response.url)
            self._write_text_file("search_results.txt", content)

        except Exception as e:
            self.logger.error(f"✗ Erreur lors de l'extraction : {e}")

        finally:
            # --- Fermeture correcte de la page Playwright ---
            if page:
                try:
                    asyncio.get_event_loop().create_task(page.close())
                except RuntimeError:
                    pass


    def _write_text_file(self, filename: str, content: str):
        """Écrit un fichier texte (utilise self.output_file)"""
        try:
            # S'assurer que le répertoire existe
            self.target_dir.mkdir(parents=True, exist_ok=True)
            with open(self.output_file, "w", encoding="utf-8") as f:
                f.write(content or "")
            self.logger.info(f"✓ Fichier écrit : {self.output_file} ({len(content)} caractères)")
            return True
        except Exception as e:
            self.logger.error(f"✗ Erreur écriture : {e}")
            import traceback
            self.logger.error(traceback.format_exc())
            return False

    def _format_for_llm(self, text: str, source_url: str) -> str:
        """
        Formate le contenu de manière optimale pour LLM et RAG.
        Structure: métadonnées YAML-like + contenu nettoyé
        """
        # Nettoyer le texte (enlever espaces multiples, lignes vides excessives)
        lines = text.split('\n')
        cleaned_lines = []
        empty_count = 0
        
        for line in lines:
            stripped = line.strip()
            if not stripped:
                empty_count += 1
                if empty_count <= 2:  # Max 2 lignes vides consécutives
                    cleaned_lines.append('')
            else:
                empty_count = 0
                cleaned_lines.append(stripped)
        
        clean_text = '\n'.join(cleaned_lines).strip()
        
        # Format structuré pour LLM/RAG
        formatted = f"""---
ingredient: {self.ingredient}
source: {source_url}
timestamp: {self._get_timestamp()}
type: ingredient_information
---

{clean_text}
"""
        return formatted

    def _get_timestamp(self) -> str:
        from datetime import datetime
        return datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

    def handle_error(self, failure):
        self.logger.error(f"✗ Erreur de requête : {failure.request.url}")
        self.logger.error(f"Raison : {failure.value}")
        # Sauvegarder un fichier d'erreur pour debugging
        try:
            error_file = self.target_dir / "error_log.txt"
            with open(error_file, "a", encoding="utf-8") as f:
                f.write(f"\n\n=== Erreur {self._get_timestamp()} ===\n")
                f.write(f"URL: {failure.request.url}\n")
                f.write(f"Erreur: {failure.value}\n")
                f.write(f"Type: {type(failure.value).__name__}\n")
        except:
            pass
