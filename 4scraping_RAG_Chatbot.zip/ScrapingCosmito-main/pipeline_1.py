import os 

def ajouter_rag(resultat):
    """
    Ajoute les produits à la base de connaissances RAG.
    """
    for product in resultat["products"]:
        print(f"Ajout du produit {product} à la base RAG.")
        # Code pour ajouter le produit à la base RAG
    for ingredient in resultat["ingredients"]:
        print(f"Ajout de l'ingrédient {ingredient} à la base RAG.")
        # Code pour ajouter l'ingrédient à la base RAG
    print("Tous les produits ont été ajoutés à la base RAG.")
