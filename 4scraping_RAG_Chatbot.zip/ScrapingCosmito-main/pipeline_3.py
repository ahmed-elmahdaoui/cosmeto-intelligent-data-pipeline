

from pipeline_0 import call_llm


def reponse_llm(user_question, rag_products, rag_ingredients):


    prompt = f"""
    Tu es un assistant expert en cosmétique.
    Tu agis comme une API qui retourne UNIQUEMENT du JSON valide.

    DOCUMENTS DE CONTEXTE (RAG) :
    {rag_ingredients}

    QUESTION UTILISATEUR :
    {user_question}

    RÈGLES STRICTES :
    1. Priorité ABSOLUE aux documents fournis.
    2. Si une information est absente des documents, tu peux fournir une information générale issue de connaissances communes en cosmétique.
    3. Toute information NON issue des documents doit être clairement signalée par la mention :
    "(Information générale – non présente dans les documents fournis)".
    4. N’invente JAMAIS de produit, ingrédient ou étude spécifique.
    5. Les liens doivent provenir UNIQUEMENT des documents. Aucun lien généré.
    6. Réponds dans la même langue que la question.
    7. Aucun texte hors JSON.

    """

    prompt += """
        Le format doit être exactement celui-ci :
        {
            "reponse": "Le texte complet de ta réponse ici..."
        }
        """

    response = call_llm(
        qes=prompt,
        model="llama-3.1-8b-instant",
        temperature=0.2,
        max_tokens=1000
    )
    return response