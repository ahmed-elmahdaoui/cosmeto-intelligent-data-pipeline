# Rôle: Construction des index (vectoriels/clé‑valeur) à partir des documents traités.
# Fournit des fonctions pour bâtir/mettre à jour l’index utilisé par le retriever.
# Exemple:
#   from rag.indexing import build_index
#   build_index(input_dir="storage/processed_documents", index_path="storage/indexes/main")

# rag/indexing.py

"""
RAGIndexer: gère la mise à jour de l'index RAG pour le chatbot.
Peut être connecté à ton moteur vectoriel (FAISS, Chroma, Pinecone, etc.).
"""

import sys 
import os
import logging
import json
from typing import Optional
from extraction.pdf_reader import PDFReader

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
logger = logging.getLogger("RAGIndexer")
logger.setLevel(logging.INFO)
ch = logging.StreamHandler()
ch.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
logger.addHandler(ch)


class RAGIndexer:
    """
    Classe responsable de l'indexation RAG (Retrieval-Augmented Generation).
    Lie les documents avec leurs métadonnées correspondantes.
    """
    
    def __init__(self, documents_path: Optional[str] = "storage\processed_documents\raw_documents\products", 
                 metadata_path: Optional[str] = "storage\processed_documents\metadata\products"):
        self.documents_path = documents_path
        self.metadata_path = metadata_path
        self.output_path = "storage/indexes"  # Chemin pour sauvegarder les JSON
        
        # Créer le dossier de sortie s'il n'existe pas
        os.makedirs(self.output_path, exist_ok=True)
        
        try:
            self.pdf_reader = PDFReader(ocr_enabled=False)
        except Exception:
            self.pdf_reader = None
        logger.info(f"RAGIndexer initialized with documents_path={self.documents_path}, metadata_path={self.metadata_path}")

    def _extract_content(self, file_path: str) -> Optional[str]:
        """
        Extrait le contenu textuel d'un fichier selon son type.
        """
        try:
            content = ""
            file_ext = os.path.splitext(file_path)[1].lower()

            if file_ext == '.pdf':
                if self.pdf_reader:
                    try:
                        content = self.pdf_reader.read(file_path)
                    except Exception as e:
                        logger.warning(f"PDFReader.read failed for {file_path}: {e}")
                        try:
                            content = PDFReader(ocr_enabled=True).read(file_path)
                        except Exception as e2:
                            logger.error(f"PDFReader with OCR also failed for {file_path}: {e2}")
                            return None
                else:
                    logger.error("No PDFReader available to read PDF files.")
                    return None

            elif file_ext in ['.txt', '.csv']:
                try:
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as fh:
                        content = fh.read()
                except Exception as e:
                    logger.error(f"Failed to read text file {file_path}: {e}")
                    return None

            elif file_ext == '.docx':
                try:
                    from docx import Document
                    doc = Document(file_path)
                    content = "\n".join(p.text for p in doc.paragraphs)
                except Exception as e:
                    logger.error(f"Failed to read docx {file_path}: {e}")
                    return None

            else:
                logger.debug(f"Unsupported file type: {file_path}")
                return None

            logger.info(f"Extracted {len(content)} characters from {file_path}")
            return content

        except Exception as e:
            logger.error(f"Failed to extract content from {file_path}: {e}")
            return None

    def _find_matching_metadata(self, document_name: str) -> Optional[dict]:
        """
        Trouve les métadonnées correspondantes pour un document.
        Format attendu: 
          document: produit_1.pdf
          metadata: metadata_produit_1.json
        """
        try:
            # Extraire le nom de base du document (sans extension)
            base_name = os.path.splitext(document_name)[0]
            
            # Construire le nom attendu du fichier de métadonnées
            
            # Fallback: chercher avec le même nom de base
            metadata_filename = f"metadata_{base_name}.json"
            
            metadata_path = os.path.join(self.metadata_path, metadata_filename)
            
            if os.path.exists(metadata_path):
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                logger.info(f"Found metadata for {document_name}: {metadata_filename}")
                return metadata
            else:
                logger.warning(f"No metadata found for {document_name}. Expected: {metadata_path}")
                return None
                
        except Exception as e:
            logger.error(f"Error loading metadata for {document_name}: {e}")
            return None

    def _save_index_entry(self, document_name: str, content: str, metadata: Optional[dict]):
        """
        Sauvegarde une entrée d'index combinant contenu et métadonnées.
        """
        try:
            # Créer l'objet structuré
            index_entry = {
                "document_name": document_name,
                "content": content,
                "metadata": metadata or {},
                "content_length": len(content),
                "timestamp": os.path.getmtime(os.path.join(self.documents_path, document_name))
            }
            
            # Nom du fichier de sortie
            output_filename = f"index_{os.path.splitext(document_name)[0]}.json"
            output_path = os.path.join(self.output_path, output_filename)
            
            # Sauvegarder en JSON
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(index_entry, f, ensure_ascii=False, indent=2)
            
            logger.info(f"Saved index entry: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Failed to save index entry for {document_name}: {e}")
            return None

    def update_index_all(self):
        """
        Parcourt tous les documents, les associe avec leurs métadonnées
        et sauvegarde le tout dans des fichiers JSON.
        """
        logger.info("Starting RAG index update with metadata linking...")

        if not os.path.exists(self.documents_path):
            logger.warning(f"Documents path '{self.documents_path}' does not exist.")
            return

        if not os.path.exists(self.metadata_path):
            logger.warning(f"Metadata path '{self.metadata_path}' does not exist.")

        # Lister les fichiers documents
        document_files = []
        for root, _, filenames in os.walk(self.documents_path):
            for f in filenames:
                if f.lower().endswith((".txt", ".pdf", ".csv", ".docx")):
                    document_files.append(f)

        logger.info(f"Found {len(document_files)} documents to process.")

        processed_count = 0
        for doc_filename in document_files:
            try:
                logger.info(f"Processing: {doc_filename}")
                
                # Étape 1: Extraire le contenu du document
                doc_path = os.path.join(self.documents_path, doc_filename)
                content = self._extract_content(doc_path)
                
                if content is None:
                    logger.warning(f"Could not extract content from {doc_filename}")
                    continue

                # Étape 2: Trouver les métadonnées correspondantes
                metadata = self._find_matching_metadata(doc_filename)
                
                # Étape 3: Sauvegarder l'entrée d'index combinée
                result_path = self._save_index_entry(doc_filename, content, metadata)
                
                if result_path:
                    processed_count += 1
                    logger.info(f"Successfully processed {doc_filename}")

            except Exception as e:
                logger.error(f"Failed to process {doc_filename}: {e}")

        logger.info(f"RAG index update complete. Processed {processed_count}/{len(document_files)} documents.")


    def get_index_stats(self) -> dict:
        """
        Retourne des statistiques sur les index générés.
        """
        if not os.path.exists(self.output_path):
            return {"total_indexes": 0}
        
        index_files = [f for f in os.listdir(self.output_path) if f.startswith("index_") and f.endswith(".json")]
        
        stats = {
            "total_indexes": len(index_files),
            "index_files": index_files
        }
        
        return stats


# Fonction utilitaire pour construire l'index
def build_index(input_dir: str = "storage\processed_documents\raw_documents\products", 
                metadata_dir: str = "storage\processed_documents\metadata\products",
                index_path: str = "storage/indexes/main"):
    """
    Fonction principale pour construire l'index.
    
    Args:
        input_dir: Chemin vers les documents traités
        metadata_dir: Chemin vers les métadonnées
        index_path: Chemin de sortie pour les index (non utilisé directement ici)
    """
    indexer = RAGIndexer(documents_path=input_dir, metadata_path=metadata_dir)
    indexer.update_index_all()
    
    stats = indexer.get_index_stats()
    logger.info(f"Index build completed. Statistics: {stats}")
    
    return stats

# ============================================================================================
import os
import uuid
import logging
import shutil
from typing import List, Dict, Any, Optional
import chromadb
from chromadb.config import Settings
from rag.embedding_provider import EmbeddingProvider

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("DocumentIndexer")

class DocumentIndexer:
    # Noms des collections (Doivent correspondre à ceux du Retriever)
    PRODUCT_COLLECTION_NAME = "cosmetovigilance_docs"
    INGREDIENT_COLLECTION_NAME = "cosmetovigilance_ingredients"

    def __init__(self, persist_directory: str = "storage/chroma_db"):
        """
        Système d'indexation Vectorielle (ChromaDB).
        Gère deux collections : Produits et Ingrédients.
        """
        self.persist_directory = persist_directory
        self.client = None
        self.embedding_provider = EmbeddingProvider()
        self._initialize_client()

    def _initialize_client(self):
        """Initialise le client ChromaDB"""
        try:
            # Création du dossier si inexistant
            os.makedirs(self.persist_directory, exist_ok=True)
            
            self.client = chromadb.PersistentClient(
                path=self.persist_directory,
                settings=Settings(anonymized_telemetry=False)
            )
            logger.info(f"✅ Client ChromaDB connecté : {self.persist_directory}")
        except Exception as e:
            logger.error(f"❌ Erreur init ChromaDB : {e}")
            raise

    def _prepare_collection(self, collection_name: str, reset: bool = False):
        """
        Prépare une collection (Création ou Reset)
        """
        try:
            # Si reset demandé, on essaie de supprimer l'existante
            if reset:
                try:
                    self.client.delete_collection(collection_name)
                    logger.info(f"🗑️ Collection '{collection_name}' supprimée (Reset).")
                except Exception:
                    # On capture "Exception" large car selon les versions de ChromaDB
                    # l'erreur peut être ValueError, NotFoundError, etc.
                    # Si on ne peut pas la supprimer (car elle n'existe pas), on continue.
                    logger.debug(f"Pas de collection '{collection_name}' à supprimer ou erreur mineure.")
                    pass

            # Création / Récupération
            collection = self.client.get_or_create_collection(
                name=collection_name,
                metadata={"description": "Index RAG Cosmetovigilance"}
            )
            return collection
        except Exception as e:
            logger.error(f"Erreur critique préparation collection '{collection_name}': {e}")
            raise

    def chunk_documents(self, documents: List[Dict[str, Any]], chunk_size: int = 1000, chunk_overlap: int = 150) -> List[Dict[str, Any]]:
        """
        Découpe les textes en morceaux (chunks) pour l'embedding.
        """
        chunks = []
        
        for doc in documents:
            # Sécurisation du contenu
            content = doc.get("content") or ""
            if not content:
                continue
                
            metadata = doc.get("metadata", {}).copy() # Copie pour éviter les effets de bord
            
            # Paramètres de base
            start = 0
            chunk_idx = 0
            
            while start < len(content):
                end = start + chunk_size
                
                # Ajustement intelligent de la fin (ne pas couper un mot/phrase)
                if end < len(content):
                    # Chercher le dernier point ou saut de ligne dans la zone de fin
                    search_zone = content[start:end]
                    last_break = max(search_zone.rfind('.'), search_zone.rfind('\n'))
                    
                    if last_break > (chunk_size * 0.5): # Si on trouve un point pas trop loin
                        end = start + last_break + 1

                chunk_text = content[start:end].strip()
                
                if len(chunk_text) > 5: # Ignorer les chunks trop petits
                    # Métadonnées enrichies pour le chunk
                    chunk_meta = metadata.copy()
                    chunk_meta.update({
                        "chunk_id": chunk_idx,
                        "chunk_size": len(chunk_text),
                        "parent_id": doc.get("id", "unknown")
                    })
                    
                    chunks.append({
                        "content": chunk_text,
                        "metadata": chunk_meta
                    })
                    chunk_idx += 1

                # Avancer avec overlap
                start = end - chunk_overlap
                if start >= len(content): break
        
        return chunks

    def _index_batch(self, documents: List[Dict[str, Any]], collection_name: str, reset: bool):
        """
        Méthode interne générique pour indexer une liste de docs dans une collection donnée.
        """
        if not documents:
            logger.warning(f"⚠️ Aucun document à indexer pour {collection_name}")
            return

        collection = self._prepare_collection(collection_name, reset=reset)
        
        # 1. Chunking
        logger.info(f"✂️ Découpage de {len(documents)} documents pour '{collection_name}'...")
        chunks = self.chunk_documents(documents)
        logger.info(f"👉 {len(chunks)} chunks générés.")

        # 2. Préparation des listes pour Chroma
        ids = [str(uuid.uuid4()) for _ in chunks]
        texts = [c["content"] for c in chunks]
        metadatas = [c["metadata"] for c in chunks]

        # 3. Embeddings (Batch processing automatique via EmbeddingProvider si géré, sinon ici)
        # Note: Chroma peut calculer les embeddings auto si on ne fournit pas 'embeddings=', 
        # mais nous utilisons votre provider custom.
        logger.info("🧠 Génération des embeddings...")
        embeddings = self.embedding_provider.get_embeddings(texts)

        # 4. Ajout (Batch par paquets de 5000 pour éviter les timeouts si grosse DB)
        batch_size = 5000
        total_chunks = len(ids)
        
        for i in range(0, total_chunks, batch_size):
            end = min(i + batch_size, total_chunks)
            collection.add(
                ids=ids[i:end],
                documents=texts[i:end],
                metadatas=metadatas[i:end],
                embeddings=embeddings[i:end]
            )
            logger.info(f"   💾 Lot {i}-{end} sauvegardé.")

        logger.info(f"✅ Indexation terminée pour '{collection_name}'. Total: {collection.count()} vecteurs.")

    # --- POINTS D'ENTRÉE PUBLICS ---

    def index_products(self, documents: List[Dict[str, Any]], reset: bool = True):
        """
        Indexe les fiches produits (PDFs, descriptions).
        Args:
            documents: Liste de dicts {'content': str, 'metadata': dict}
            reset: Si True, vide la collection avant (Recommandé).
        """
        logger.info("🚀 Démarrage indexation PRODUITS")
        self._index_batch(documents, self.PRODUCT_COLLECTION_NAME, reset)

    def index_ingredients(self, documents: List[Dict[str, Any]], reset: bool = True):
        """
        Indexe les fiches scientifiques des ingrédients.
        Args:
            documents: Liste de dicts {'content': str, 'metadata': dict}
            reset: Si True, vide la collection avant (Recommandé).
        """
        logger.info("🚀 Démarrage indexation INGRÉDIENTS")
        self._index_batch(documents, self.INGREDIENT_COLLECTION_NAME, reset)

    def clear_database(self):
        """Danger: Supprime TOUT le dossier de base de données"""
        if os.path.exists(self.persist_directory):
            shutil.rmtree(self.persist_directory)
            logger.warning("☢️ Base de données ChromaDB physiquement supprimée.")
            self._initialize_client()

# Instance globale
document_indexer = DocumentIndexer()

# # =======================================================
# # EXEMPLE D'UTILISATION DANS VOTRE PIPELINE PRINCIPAL
# # =======================================================
# if __name__ == "__main__":
#     # Simulation de données
#     docs_produits = [
#         {"content": "La Crema S de Unilever est hydratante.", "metadata": {"type": "product", "name": "Crema S"}},
#         {"content": "Shampooing Dove antipelliculaire.", "metadata": {"type": "product", "name": "Dove"}}
#     ]
    
#     docs_ingredients = [
#         {"content": "La Glycérine est un agent humectant.", "metadata": {"type": "ingredient", "name": "Glycerin"}},
#         {"content": "Le Retinol peut être irritant.", "metadata": {"type": "ingredient", "name": "Retinol"}}
#     ]

#     indexer = DocumentIndexer()
    
#     # 1. Indexer les produits
#     indexer.index_products(docs_produits, reset=True)
    
#     # 2. Indexer les ingrédients
#     indexer.index_ingredients(docs_ingredients, reset=True)