"""Rôle: Lecture de PDF (extraction texte structuré ou brut).
Exemple:
	from extraction.pdf_reader import read_pdf
	texte = read_pdf("storage/raw_documents/doc.pdf")
"""
# Rôle: Lecture et extraction de texte depuis des PDF (non scannés).
# Fournit des helpers pour convertir PDF → texte brut utilisable.
# extraction/pdf_reader.py
"""
PDFReader: Extraction de texte depuis des fichiers PDF.
- Supporte PDFs textuels et PDFs scannés (OCR)
- PyPDF2 pour texte natif
- pytesseract + pdf2image pour PDFs scannés

Usage:
    reader = PDFReader()
    text = reader.read("storage/raw_documents/product1/doc1.pdf")
"""

import logging
from pathlib import Path
from typing import Optional

import PyPDF2
from pdf2image import convert_from_path  # pip install pdf2image
import pytesseract  # pip install pytesseract

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class PDFReader:
    """
    Classe pour lire du texte depuis des fichiers PDF.
    """

    def __init__(self, ocr_enabled: bool = True, ocr_dpi: int = 300):
        """
        Args:
            ocr_enabled (bool): Si True, tentera OCR pour PDFs scannés
            ocr_dpi (int): résolution pour convertir les pages en images
        """
        self.ocr_enabled = ocr_enabled
        self.ocr_dpi = ocr_dpi

    def read(self, path: str) -> str:
        """
        Lit un PDF et retourne le texte.
        - Essaie d'abord extraction native via PyPDF2
        - Si texte vide et OCR activé -> utilise OCR sur images

        Args:
            path (str): Chemin du fichier PDF

        Returns:
            str: texte extrait, ou "" si erreur
        """
        path_obj = Path(path)
        if not path_obj.exists() or not path_obj.is_file():
            logger.warning(f"PDFReader: fichier introuvable: {path}")
            return ""

        # 1) Extraction texte natif via PyPDF2
        text = self._read_pdf_text(path)
        if text.strip():
            return text.strip()

        # 2) Si texte vide et OCR activé -> OCR
        if self.ocr_enabled:
            logger.info(f"PDFReader: texte vide, tentative OCR pour {path}")
            try:
                text = self._read_pdf_ocr(path)
                return text.strip()
            except Exception as e:
                logger.exception(f"PDFReader: erreur OCR {path}: {e}")

        return ""

    # ------------------------
    # Extraction texte PyPDF2
    # ------------------------
    def _read_pdf_text(self, path: str) -> str:
        try:
            text = ""
            with open(path, "rb") as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            return text
        except Exception as e:
            logger.warning(f"PDFReader: erreur PyPDF2 lecture {path}: {e}")
            return ""

    # ------------------------
    # Extraction OCR via pdf2image + pytesseract
    # ------------------------
    def _read_pdf_ocr(self, path: str) -> str:
        try:
            images = convert_from_path(path, dpi=self.ocr_dpi)
            ocr_text = ""
            for i, img in enumerate(images):
                page_text = pytesseract.image_to_string(img)
                ocr_text += page_text + "\n"
            return ocr_text
        except Exception as e:
            logger.exception(f"PDFReader: erreur OCR lecture {path}: {e}")
            return ""
