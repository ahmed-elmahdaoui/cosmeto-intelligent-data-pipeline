
from groq import Groq
import subprocess
import re
import json
import os
from datetime import datetime, timezone


API_KEY = "VOTRE_CLE_Groq_ICI"
path_ingredients = "./storage/processed_documents/raw_documents/ingredients/"
path_ingredients_metadata = "./storage/processed_documents/metadata/ingredients/metadata_"
path_products = "./storage/processed_documents/raw_documents/products/"
path_products_metadata = "./storage/processed_documents/metadata/products/metadata_"
def ajouter_produit(product_name):
    """
    Ajoute un produit à la fin du fichier data/products/products.txt.
    Si le fichier ou le dossier n'existe pas, il les crée.
    """
    # Chemin complet du fichier
    folder_path = "./data/products"
    file_path = os.path.join(folder_path, "products.txt")

    # Créer le dossier s'il n'existe pas
    os.makedirs(folder_path, exist_ok=True)

    # Ouvrir le fichier en mode ajout ('a') et écrire le produit
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(product_name + "\n")  # ajouter un saut de ligne

def lire_tous_les_produits():
    """
    Lit tous les produits dans data/products/products.txt
    et retourne une liste de produits.
    """
    file_path = "data/products/products.txt"
    
    # Vérifier si le fichier existe
    if not os.path.exists(file_path):
        print(f"Le fichier {file_path} n'existe pas.")
        return []

    # Lire tous les produits
    with open(file_path, "r", encoding="utf-8") as f:
        produits = [ligne.strip() for ligne in f if ligne.strip()]

    return produits

def create_metadata(ingredient: str, text: str, category: str = "cosmetics", language: str = "fr") -> dict:
    """
    Crée un dictionnaire de métadonnées pour un ingrédient à partir d'un texte brut.
    Fonction robuste pour différents formats de CAS et InChIKey.
    """
    
    # Extraire CAS : format standard xxxxx-xx-x
    cas_match = re.findall(r"\b\d{1,7}-\d{2}-\d\b", text)
    cas = cas_match[0] if cas_match else "Not specified"
    
    # Extraire InChIKey : 27 caractères en majuscule et chiffres, avec tirets
    inchikey_match = re.findall(r"\b[A-Z]{14}-[A-Z]{10}-[A-Z]\b", text)
    inchikey = inchikey_match[0] if inchikey_match else "Not specified"
    
    # Extraire source s'il existe
    source_match = re.findall(r"source:\s*(https?://[^\s]+)", text)
    source = source_match[0] if source_match else "Not specified"
    
    metadata = {
        "ingredient": ingredient,
        "CAS": cas,
        "InChIKey": inchikey,
        "source": source,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "type": "ingredient_information",
        "category": category,
        "language": language
    }
    
    return metadata

def create_product_metadata(product_name: str, text: str) -> dict:
    # Extract brand
    brand_match = re.search(r'Brands:\s*(.+)', text)
    brand = brand_match.group(1).strip() if brand_match else "Not specified"

    # Extract barcode (EAN)
    barcode_match = re.search(r'Barcode:\s*(\d+)', text)
    barcode = barcode_match.group(1).strip() if barcode_match else "Not specified"

    # Extract categories
    categories_match = re.search(r'Categories:\s*(.+)', text)
    if categories_match:
        categories = [cat.strip() for cat in categories_match.group(1).split('\n') if cat.strip()]
    else:
        categories = []

    # Extract timestamp
    timestamp_match = re.search(r'timestamp:\s*(.+)', text)
    if timestamp_match:
        timestamp_str = timestamp_match.group(1).strip()
        try:
            timestamp = datetime.strptime(timestamp_str, "%Y-%m-%d %H:%M:%S UTC").replace(tzinfo=timezone.utc).isoformat()
        except:
            timestamp = datetime.now(timezone.utc).isoformat()
    else:
        timestamp = datetime.now(timezone.utc).isoformat()

    # Extract source URL
    source_match = re.search(r'source_url:\s*(.+)', text)
    source_url = source_match.group(1).strip() if source_match else "Not specified"

    metadata = {
        "product_name": product_name,
        "brand": brand,
        "barcode": barcode,
        "categories": categories,
        "source": source_url,
        "timestamp": timestamp,
        "type": "product_information",
        "language": "fr"
    }

    return metadata

def summarize_quantitative_text(texts, max_sentences=5, max_chars=500):
    """
    Résumé compact des informations chimiques à partir d'un ou plusieurs textes.
    Limite le nombre de phrases par catégorie et la longueur des extraits.
    """
    # Combiner tous les textes en un seul
    if isinstance(texts, list):
        text = "\n".join(texts)
    else:
        text = texts

    summary = {}

    def get_context(pattern):
        sentences = re.split(r'(?<=[.!?])\s+', text)
        results = []
        for s in sentences:
            if re.search(pattern, s, re.IGNORECASE):
                # Limiter la longueur de chaque phrase
                snippet = s.strip()
                if len(snippet) > max_chars:
                    snippet = snippet[:max_chars].rstrip() + "..."
                results.append(snippet)
        # Garde uniquement un nombre limité de phrases
        results = results[:max_sentences]
        return results if results else ["Not specified"]



    # CAS RN
    summary['CAS'] = get_context(r"CAS\s*(RN|Number)?\s*[:\n]*[\s]*[\d\-]+")
    # InChIKey
    summary['InChIKey'] = get_context(r"InChIKey\s*[:\n]*[\s]*[A-Z0-9\-]+")
    # Formes chimiques / polymères
    summary['Chemical Forms'] = get_context(r"(monomer|dimer|trimer|tetramer|hexamer|oligomer|radical ion|polymer)")
    # Propriétés chimiques et physiques
    summary['Chemical Properties'] = get_context(r"(NMR|MS|GC-MS|crystallograph[y|ic]|3D structure|ligand|formula|solubility|density|melting point)")
    # Interactions biologiques
    summary['Biological Interactions'] = get_context(r"(protein|enzyme|receptor|metabolic pathway|bioassay|toxicity assay)")
    # Toxicité et sécurité
    summary['Toxicity & Safety'] = get_context(r"(genotoxicity|GHS|EPA|EFSA|health effect|safety|toxic|hazard)")

    # Construire le texte final
    final_text = "Inf: " +text[:200] +"\n"
    for key, contexts in summary.items():
        final_text += f"{key}:\n"
        for c in contexts:
            final_text += f"  - {c}\n"
        final_text += "\n"
    return final_text

def run_ingredient_spider(ingredient_name: str, source: str = "pubchem"):
    """Lance le spider pour un ingrédient"""
    print(f"\n{'='*60}")
    print(f"🔬 Recherche ingrédient: {ingredient_name} (source: {source.upper()})")
    print(f"{'='*60}\n")
    
    cmd = [
        "scrapy", "crawl", "ingredient_search_spider",
        "-a", f"ingredient={ingredient_name}",
        "-a", f"source={source}"
    ]
    
    try:
        result = subprocess.run(cmd, check=True)
        print(f"\n✅ Ingrédient '{ingredient_name}' terminé avec succès\n")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erreur pour ingrédient '{ingredient_name}': {e}\n")
        return False

def run_product_spider(product_name: str):
    """Lance le spider pour un produit"""
    print(f"\n{'='*60}")
    print(f"🔍 Recherche produit: {product_name}")
    print(f"{'='*60}\n")
    
    cmd = [
        "scrapy", "crawl", "document_search_spider",
        "-a", f"product={product_name}"
    ]
    
    try:
        result = subprocess.run(cmd, check=True)
        print(f"\n✅ Produit '{product_name}' terminé avec succès\n")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erreur pour produit '{product_name}': {e}\n")
        return False

def ajouter_ingredient(ingredient_name):
    """
    Ajoute un ingrédient à la fin du fichier data/products/ingredients.txt.
    Si le fichier ou le dossier n'existe pas, il les crée.
    """
    # Chemin complet du fichier
    folder_path = "data/ingredients"
    file_path = os.path.join(folder_path, "ingredients.txt")

    # Créer le dossier s'il n'existe pas
    os.makedirs(folder_path, exist_ok=True)

    # Ouvrir le fichier en mode ajout ('a') et écrire l'ingrédient
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(ingredient_name + "\n") 

def lire_tous_les_ingredients():
    """
    Lit tous les ingrédients dans data/products/ingredients.txt
    et retourne une liste d'ingrédients.
    """
    file_path = "data/ingredients/ingredients.txt"
    
    # Vérifier si le fichier existe
    if not os.path.exists(file_path):
        print(f"Le fichier {file_path} n'existe pas.")
        return []

    # Lire tous les ingrédients
    with open(file_path, "r", encoding="utf-8") as f:
        ingredients = [ligne.strip() for ligne in f if ligne.strip()]

    return ingredients

i = 0
def call_llm(qes = "", model="llama-3.1-8b-instant", max_tokens=500, temperature=0):
    global i
    client = Groq( api_key=API_KEY)
    chat_completion = client.chat.completions.create(
        messages=[
            {
                "role": "user",
                "content": qes,
            }
        ],
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,

    )
    try:
        i = 0
        resultat = json.loads(chat_completion.choices[0].message.content)
    except:
        i += 1
        if i < 4:
            if i == 1:
                qes = qes + "\n Régle : \nLa réponse précédente n'était pas un JSON valide. Merci de répondre **uniquement en JSON**.\n" + qes
            return call_llm(qes)
        resultat = {"products": [], "ingredients": [], "etat": False}
    return resultat 

prompt_base = """
Agis comme une base de données cosmétiques. Pour chaque produit que je te donne, retourne **uniquement un JSON** :

{
  "products": ["type_ou_marque_principal"],
  "ingredients": ["Ingrédient1", ...],
  "etat": true | false
}

Règles :  
1. Remplis `products` avec **le mot clé principal du produit ou de la marque**.
2. Remplis `ingredients` avec les principaux composants connus du produit.
3. Si le produit n’est pas un cosmétique, retourne {"products": [], "ingredients": [], "etat": false}.

Répond strictement en JSON.
---
Produit:
"""

prompt =  """
Agis comme une base de données cosmétiques. Pour chaque question, retourne **uniquement un JSON** :

{
  "products": ["type_ou_marque1", ...],
  "ingredients": ["Ingrédient1", ...],
  "etat": true | false
}

Règles :  
1. Si la question concerne des cosmétiques, remplis `products` avec **uniquement le mot clé principal du type ou de la marque** (ex : "Rouge" pour "Rouge à lèvres hydratant") et `ingredients` avec les principaux composants, `"etat": true`.  
2. Si la question **n’a rien à voir avec les cosmétiques**, retourne : {"products": [], "ingredients": [], "etat": false}

Répond strictement en JSON.
---
Question:
"""

def point_end(qestion, type = "Q") : 
    """ 
        qestion : str le texte de la question
        type : str type de prempt ("Q" pour question cosmétique, "P" pour produit)
    """
    if type == "Q":
        qes = prompt + qestion + "---"
    else :
        qes = prompt_base + qestion + "---"
    resultat = call_llm(qes)
   
    if resultat["etat"]:
        for product in resultat["products"]:
            produits = lire_tous_les_produits()
            if product not in produits:
                run_product_spider(product)
                ajouter_produit(product)
            else : 
                continue
            file = product.lower().replace(" ", "_") + ".txt"
            if not os.path.exists(os.path.join(path_products, file)):
                continue
            with open(os.path.join(path_products, file), "r", encoding="utf-8") as f:
                text = f.read()
            metadata_entry = create_product_metadata(product, text)
            metadata_file = path_products_metadata + product.lower().replace(" ", "_") + ".json"
            os.makedirs(os.path.dirname(metadata_file), exist_ok=True)
            with open(metadata_file, "w", encoding="utf-8") as f:
                json.dump(metadata_entry, f, ensure_ascii=False, indent=4)
            

        for ingredient in resultat["ingredients"]:
            ingredients = lire_tous_les_ingredients()
            if ingredient not in ingredients:
                run_ingredient_spider(ingredient, source="pubchem")
                ajouter_ingredient(ingredient)
            else : 
                print("Déjà existant :", ingredient)
                continue
            file = ingredient.lower().replace(" ", "_") + ".txt"
            if not os.path.exists(os.path.join(path_ingredients, file)):
                continue
            with open(os.path.join(path_ingredients, file), "r", encoding="utf-8") as f:
                text = f.read()
            summary = summarize_quantitative_text(text)
            metadata_entry = create_metadata(ingredient, summary)

            with open(os.path.join(path_ingredients, file), "w", encoding="utf-8") as f:
                f.write(summary)
            metadata_file = path_ingredients_metadata + ingredient.lower().replace(" ", "_") + ".json"
            os.makedirs(os.path.dirname(metadata_file), exist_ok=True)
            with open(metadata_file, "w", encoding="utf-8") as f:
                json.dump(metadata_entry, f, ensure_ascii=False, indent=4)
    return resultat
