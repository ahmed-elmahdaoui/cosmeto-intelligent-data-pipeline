"""
manager.py

Rôle :
    Orchestration centrale des spiders pour le projet CosmetoDataForge.
    - Lit la configuration des sites à crawler depuis config/base.yaml.
    - Pour chaque site, cherche un spider spécifique ; si aucun spider n'existe, utilise GenericSpider.
    - Passe dynamiquement les paramètres : start_urls, description, tables_qui_possible_remplir.
    - Lance tous les spiders via Scrapy CrawlerProcess.
    - Permet d’ajouter facilement de nouveaux sites sans modifier le code du manager.

Auteur : [Votre Nom]
Date : 2025-11-09
"""
# crawlers/manager.py
import os
import yaml
import importlib
from scrapy.crawler import CrawlerProcess
from multiprocessing import get_context
from scrapy.utils.project import get_project_settings
from scrapy.utils.log import configure_logging

CONFIG_PATH = "config/base.yaml"


def load_config(path=CONFIG_PATH):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception:
        # Fallback minimal si PyYAML absent ou fichier introuvable
        print("[manager] ⚠️ Impossible de charger config/base.yaml. Utilisation d'une config minimale.")
        return {"targets": {"sites": []}, "crawler": {}, "paths": {}}


def get_spider_class(spider_name):
    """Import dynamique d'un spider dédié, avec découverte souple des classes.

    Stratégie:
    - Importer le module crawlers.spiders.<spider_name>_spider
    - Chercher une classe qui:
        * s'appelle <CamelCase(spider_name)> + 'Spider', ou
        * a un attribut 'name' égal à f"{spider_name}_spider" ou "{spider_name}"
    - Sinon, fallback vers SearchDownloadSpider.
    """
    module = None
    try:
        module = importlib.import_module(f"crawlers.spiders.{spider_name}_spider")
        # 1) tentative par nom CamelCase
        class_name = ''.join([part.capitalize() for part in spider_name.split('_')]) + "Spider"
        if hasattr(module, class_name):
            return getattr(module, class_name)
        # 2) balayage par attribut 'name'
        for attr in dir(module):
            obj = getattr(module, attr)
            try:
                if getattr(obj, "name", None) in (f"{spider_name}_spider", spider_name):
                    return obj
            except Exception:
                continue
    except ModuleNotFoundError:
        pass
    # Fallback générique
    try:
        module_fallback = importlib.import_module("crawlers.spiders.search_download_spider")
        return getattr(module_fallback, "SearchDownloadSpider")
    except Exception:
        print(f"⚠️ Spider non trouvé et fallback indisponible : {spider_name}")
        return None


def run_spiders(search_type, search_name, mode: str = "list"):
    """
    Lancer automatiquement les spiders pertinents
    :param search_type: type de recherche ('produit', 'ingredient', etc.)
    :param search_name: nom ou mot-clé à rechercher
    """
    configure_logging()
    settings = get_project_settings()
    # Spawn context for Windows safety when using process pools in spiders
    try:
        mp_ctx = get_context("spawn")
    except Exception:
        mp_ctx = None
    process = CrawlerProcess(settings)

    config = load_config()
    output_cfg = (config or {}).get("output", {})
    # FEEDS will still write to OUTPUT_PATH but aggregation pipeline writes per type
    if output_cfg.get("output_path"):
        os.environ["OUTPUT_PATH"] = output_cfg["output_path"]
    sites = config.get("targets", {}).get("sites", [])

    # Déterminer le mode d'exécution
    mode = (mode or "list").lower()

    paths_cfg = (config or {}).get("paths", {})
    raw_root = paths_cfg.get("raw_documents", "storage/raw_documents/")
    storage_base = os.path.join(raw_root, search_type)
    os.makedirs(storage_base, exist_ok=True)

    if mode == "list":
        # Lister les URLs par site avec ListingSpider
        try:
            from crawlers.spiders.listing_spider import ListingSpider
        except Exception as e:
            print(f"⛔ Impossible d'importer ListingSpider: {e}")
            raise

        for site in sites:
            name = site.get("name")
            url = site.get("url")
            description = site.get("description", "")
            tables = site.get("tables_qui_possible_remplir", [])
            capabilities = site.get("capabilities", [])

            if search_type not in capabilities:
                continue

            print(f"\n� Listing des URLs avec spider: {name}")
            print(f"🔗 URL: {url}")
            print(f"� Recherche: {search_type} = {search_name}\n")

            process.crawl(
                ListingSpider,
                site_name=name,
                start_urls=[url],
                description=description,
                tables_qui_possible_remplir=tables,
                search_type=search_type,
                search_name=search_name,
                storage_dir=storage_base,
                download_on_discovery=False,
            )
    elif mode == "stream":
        # Lister et télécharger immédiatement à la découverte (streaming)
        try:
            from crawlers.spiders.listing_spider import ListingSpider
        except Exception as e:
            print(f"⛔ Impossible d'importer ListingSpider: {e}")
            raise

        for site in sites:
            name = site.get("name")
            url = site.get("url")
            description = site.get("description", "")
            tables = site.get("tables_qui_possible_remplir", [])
            capabilities = site.get("capabilities", [])

            if search_type not in capabilities:
                continue

            print(f"\n⚡ Streaming (discover+download) avec spider: {name}")
            print(f"🔗 URL: {url}")
            print(f"🔍 Recherche: {search_type} = {search_name}\n")

            process.crawl(
                ListingSpider,
                site_name=name,
                start_urls=[url],
                description=description,
                tables_qui_possible_remplir=tables,
                search_type=search_type,
                search_name=search_name,
                storage_dir=storage_base,
                download_on_discovery=True,
            )
    elif mode == "download":
        # Lancer un seul spider pour télécharger à partir du fichier lines
        try:
            from crawlers.spiders.download_from_lines_spider import DownloadFromLinesSpider
        except Exception as e:
            print(f"⛔ Impossible d'importer DownloadFromLinesSpider: {e}")
            raise

        # Assurer que le fichier lines existe; sinon exécuter une phase LIST d'abord
        lines_dir = os.path.join("storage", "json_output", search_type)
        os.makedirs(lines_dir, exist_ok=True)
        norm_name = (search_name or "").strip().lower().replace(" ", "_")
        lines_file = os.path.join(lines_dir, f"lines_{norm_name}.txt")

        if not os.path.exists(lines_file):
            print(f"\n🧭 Aucune liste trouvée ({lines_file}). Exécution d'une phase 'list' préalable…")
            # Phase LIST préalable
            try:
                from crawlers.spiders.listing_spider import ListingSpider
            except Exception as e:
                print(f"⛔ Impossible d'importer ListingSpider: {e}")
                raise

            # Nouveau process pour garantir l'ordre (list -> download)
            list_proc = CrawlerProcess(settings)
            for site in sites:
                name = site.get("name")
                url = site.get("url")
                description = site.get("description", "")
                tables = site.get("tables_qui_possible_remplir", [])
                capabilities = site.get("capabilities", [])
                if search_type not in capabilities:
                    continue
                list_proc.crawl(
                    ListingSpider,
                    site_name=name,
                    start_urls=[url],
                    description=description,
                    tables_qui_possible_remplir=tables,
                    search_type=search_type,
                    search_name=search_name,
                    storage_dir=storage_base,
                    download_on_discovery=False,
                )
            list_proc.start()

        print(f"\n⬇️ Téléchargement depuis lines pour: {search_type} / {search_name}")
        process.crawl(
            DownloadFromLinesSpider,
            search_type=search_type,
            search_name=search_name,
            storage_dir=storage_base,
        )
    else:
        print(f"⛔ Mode inconnu: {mode}. Utilisez 'list' ou 'download'.")
        raise SystemExit(2)

    process.start()


if __name__ == "__main__":
    # Usage: python -m crawlers.manager type_sites=<capability> nom="vitamine c"
    import sys
    type_sites = None
    nom = None
    mode = "list"
    for arg in sys.argv[1:]:
        if arg.startswith("type_sites="):
            type_sites = arg.split("=", 1)[1]
        elif arg.startswith("nom="):
            nom = arg.split("=", 1)[1]
        elif arg.startswith("mode="):
            mode = arg.split("=", 1)[1]
    if not type_sites or not nom:
        print("Usage: python -m crawlers.manager type_sites=<capability> nom=<terme> [mode=list|download|stream]")
        raise SystemExit(1)
    run_spiders(type_sites, nom, mode)

