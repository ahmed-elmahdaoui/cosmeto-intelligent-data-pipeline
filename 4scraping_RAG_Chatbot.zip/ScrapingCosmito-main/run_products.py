#!/usr/bin/env python3
"""
Script pour lancer le spider de recherche de produits à partir d'un fichier texte.

Usage:
    python run_products.py products.txt

Format du fichier:
    Chaque ligne = un nom de produit à chercher
    
Exemple products.txt:
    deodorant
    shampoo
    retinol serum
    vitamin c cream
"""

import sys
import subprocess
from pathlib import Path


def run_product_spider(product_name: str):
    """Lance le spider pour un produit"""
    print(f"\n{'='*60}")
    print(f"🔍 Recherche produit: {product_name}")
    print(f"{'='*60}\n")
    
    cmd = [
        "scrapy", "crawl", "document_search_spider",
        "-a", f"product={product_name}"
    ]
    
    try:
        result = subprocess.run(cmd, check=True)
        print(f"\n✅ Produit '{product_name}' terminé avec succès\n")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erreur pour produit '{product_name}': {e}\n")
        return False


def main():
    if len(sys.argv) < 2:
        print("Usage: python run_products.py <fichier_produits.txt>")
        print("\nExemple:")
        print("  python run_products.py products.txt")
        sys.exit(1)
    
    file_path = Path(sys.argv[1])
    
    if not file_path.exists():
        print(f"❌ Fichier introuvable: {file_path}")
        sys.exit(1)
    
    # Lire le fichier
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Nettoyer et filtrer les lignes
    products = [line.strip() for line in lines if line.strip() and not line.strip().startswith('#')]
    
    if not products:
        print(f"❌ Aucun produit trouvé dans {file_path}")
        sys.exit(1)
    
    print(f"📋 {len(products)} produit(s) à traiter depuis {file_path}")
    print(f"{'='*60}\n")
    
    # Statistiques
    success_count = 0
    failed_count = 0
    
    # Lancer le spider pour chaque produit
    for i, product in enumerate(products, 1):
        

        print(f"[{i}/{len(products)}] Traitement: {product}")
        
        if run_product_spider(product):
            success_count += 1
        else:
            failed_count += 1
    
    # Résumé
    print(f"\n{'='*60}")
    print(f"📊 RÉSUMÉ")
    print(f"{'='*60}")
    print(f"✅ Réussis: {success_count}")
    print(f"❌ Échoués: {failed_count}")
    print(f"📁 Résultats dans: storage/processed_documents/raw_documents/products/")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
