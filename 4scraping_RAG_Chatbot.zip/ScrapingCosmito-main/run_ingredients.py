#!/usr/bin/env python3
"""
Script pour lancer le spider de recherche d'ingrédients à partir d'un fichier texte.

Usage:
    python run_ingredients.py ingredients.txt [source]

Arguments:
    ingredients.txt : Fichier contenant les ingrédients (un par ligne)
    source         : "pubchem" (défaut) ou "drugbank"

Format du fichier:
    Chaque ligne = un nom d'ingrédient à chercher
    
Exemple ingredients.txt:
    glycerin
    niacinamide
    retinol
    hyaluronic acid
"""

import sys
import subprocess
from pathlib import Path


def run_ingredient_spider(ingredient_name: str, source: str = "pubchem"):
    """Lance le spider pour un ingrédient"""
    print(f"\n{'='*60}")
    print(f"🔬 Recherche ingrédient: {ingredient_name} (source: {source.upper()})")
    print(f"{'='*60}\n")
    
    cmd = [
        "scrapy", "crawl", "ingredient_search_spider",
        "-a", f"ingredient={ingredient_name}",
        "-a", f"source={source}"
    ]
    
    try:
        result = subprocess.run(cmd, check=True)
        print(f"\n✅ Ingrédient '{ingredient_name}' terminé avec succès\n")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n❌ Erreur pour ingrédient '{ingredient_name}': {e}\n")
        return False


def main():
    if len(sys.argv) < 2:
        print("Usage: python run_ingredients.py <fichier_ingredients.txt> [source]")
        print("\nArguments:")
        print("  fichier_ingredients.txt : Fichier contenant les ingrédients")
        print("  source                  : 'pubchem' (défaut) ou 'drugbank'")
        print("\nExemple:")
        print("  python run_ingredients.py ingredients.txt")
        print("  python run_ingredients.py ingredients.txt pubchem")
        sys.exit(1)
    
    file_path = Path(sys.argv[1])
    source = sys.argv[2] if len(sys.argv) > 2 else "pubchem"
    
    if source not in ["pubchem", "drugbank"]:
        print(f"❌ Source invalide: {source} (utilisez 'pubchem' ou 'drugbank')")
        sys.exit(1)
    
    if not file_path.exists():
        print(f"❌ Fichier introuvable: {file_path}")
        sys.exit(1)
    
    # Lire le fichier
    with open(file_path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Nettoyer et filtrer les lignes
    ingredients = [line.strip() for line in lines if line.strip() and not line.strip().startswith('#')]
    
    if not ingredients:
        print(f"❌ Aucun ingrédient trouvé dans {file_path}")
        sys.exit(1)
    
    print(f"📋 {len(ingredients)} ingrédient(s) à traiter depuis {file_path}")
    print(f"🔍 Source: {source.upper()}")
    print(f"{'='*60}\n")
    
    # Statistiques
    success_count = 0
    failed_count = 0
    
    # Lancer le spider pour chaque ingrédient
    for i, ingredient in enumerate(ingredients, 1):
        print(f"[{i}/{len(ingredients)}] Traitement: {ingredient}")
        
        if run_ingredient_spider(ingredient, source):
            success_count += 1
        else:
            failed_count += 1
    
    # Résumé
    print(f"\n{'='*60}")
    print(f"📊 RÉSUMÉ")
    print(f"{'='*60}")
    print(f"✅ Réussis: {success_count}")
    print(f"❌ Échoués: {failed_count}")
    print(f"📁 Résultats dans: storage/processed_documents/raw_documents/ingredients/")
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
