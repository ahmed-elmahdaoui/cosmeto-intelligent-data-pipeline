# Cosmétovigilance RAG Application

Interface utilisateur Streamlit pour l'application de Cosmétovigilance RAG.

## Fonctionnalités

- Interface professionnelle et conviviale
- Formulaire de soumission de questions sur la cosmétovigilance
- Affichage clair des réponses générées par le système RAG
- Visualisation des sources de données consultées
- Configuration du modèle LLM et de la température
- Historique des questions (à implémenter)

## Prérequis

- Python 3.8 ou supérieur

## Installation

1. Clonez ce dépôt
2. Installez les dépendances :
   ```
   pip install -r requirements.txt
   ```

## Lancement de l'application

Exécutez la commande suivante :
```
streamlit run app.py
```

L'application sera accessible à l'adresse `http://localhost:8501` dans votre navigateur.

## Structure du projet

- `app.py` : Application principale Streamlit
- `requirements.txt` : Dépendances Python

## À faire

- Connecter l'application à l'API RAG réelle
- Implémenter l'historique des questions
- Ajouter des fonctionnalités supplémentaires selon les besoins